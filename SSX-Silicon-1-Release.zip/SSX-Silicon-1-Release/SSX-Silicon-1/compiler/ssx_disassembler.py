"""
SSX Silicon 1 (SSX-32) Disassembler
Creator: Samin Sami (SS)
Disassembles 32-bit SSX machine code into formatted assembly instructions.
"""

import sys
import os
from typing import List, Tuple
try:
    from ssx_isa import (
        OPCODE_NAMES, TWO_WORD_OPCODES, unpack_instruction
    )
except ImportError:
    from compiler.ssx_isa import (
        OPCODE_NAMES, TWO_WORD_OPCODES, unpack_instruction
    )

def disassemble_word(word: int, next_word: int = None) -> Tuple[str, int]:
    """
    Disassembles a word and optionally consumes a second word.
    Returns (disassembly_string, words_consumed).
    """
    opcode, rd, rs1, rs2, imm9, imm9_signed = unpack_instruction(word)
    opname = OPCODE_NAMES.get(opcode, f"0x{opcode:02X}")

    if opcode in (0x00, 0x01, 0x02, 0x04, 0x05, 0x5A):
        # NOP, HLT, RESET, CLC, STC, RET
        return f"{opname}", 1

    if opcode == 0x03:  # SYS
        return f"SYS #{imm9}", 1

    if opcode == 0x10:  # MOV Rd, Rs
        return f"MOV R{rd}, R{rs1}", 1

    if opcode == 0x11:  # LOAD Rd, [Rs]
        return f"LOAD R{rd}, [R{rs1}]", 1

    if opcode == 0x12:  # STORE Rs, [Rd]
        return f"STORE R{rs1}, [R{rd}]", 1

    if opcode == 0x13:  # LOADI Rd, #imm32
        val = next_word if next_word is not None else 0
        return f"LOADI R{rd}, 0x{val:08X}", 2

    if opcode == 0x14:  # STOREI #imm32, [Rd]
        val = next_word if next_word is not None else 0
        return f"STOREI 0x{val:08X}, [R{rd}]", 2

    if opcode == 0x15:  # PUSH Rs
        return f"PUSH R{rs1}", 1

    if opcode == 0x16:  # POP Rd
        return f"POP R{rd}", 1

    if opcode in (0x20, 0x22, 0x24, 0x25, 0x26, 0x30, 0x32, 0x34):
        # ADD, SUB, MUL, DIV, MOD, AND, OR, XOR
        return f"{opname} R{rd}, R{rs1}, R{rs2}", 1

    if opcode in (0x21, 0x23, 0x31, 0x33, 0x35):
        # ADDI, SUBI, ANDI, ORI, XORI
        return f"{opname} R{rd}, R{rs1}, #{imm9_signed}", 1

    if opcode in (0x27, 0x28, 0x29, 0x36):
        # INC, DEC, NEG, NOT
        return f"{opname} R{rd}", 1

    if opcode in (0x37, 0x38, 0x39, 0x3A, 0x3B):
        # SHL, SHR, SAR, ROL, ROR
        return f"{opname} R{rd}, R{rs1}, #{imm9 & 0x1F}", 1

    if opcode in (0x40, 0x42):
        # CMP, TST
        return f"{opname} R{rs1}, R{rs2}", 1

    if opcode == 0x41:  # CMPI
        return f"CMPI R{rs1}, #{imm9_signed}", 1

    if opcode in (0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59):
        # JMP, JE, JNE, JL, JLE, JG, JGE, JC, JNC, CALL
        target = next_word if next_word is not None else 0
        return f"{opname} 0x{target:04X}", 2

    if opcode == 0x60:  # OUT port, Rs
        return f"OUT #{imm9}, R{rs1}", 1

    if opcode == 0x61:  # IN Rd, port
        return f"IN R{rd}, #{imm9}", 1

    if opcode == 0x62:  # VSET Rx, Ry, Rc
        return f"VSET R{rs1}, R{rs2}, R{rd}", 1

    if opcode == 0x63:  # VCLR
        return f"VCLR #{imm9}", 1

    return f".WORD 0x{word:08X}", 1

def disassemble_program(words: List[int]) -> List[str]:
    lines = []
    i = 0
    while i < len(words):
        w = words[i]
        next_w = words[i + 1] if i + 1 < len(words) else None
        text, consumed = disassemble_word(w, next_w)
        if consumed == 2:
            lines.append(f"{i:04X}: {w:08X} {next_w:08X}   {text}")
            i += 2
        else:
            lines.append(f"{i:04X}: {w:08X}            {text}")
            i += 1
    return lines

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python ssx_disassembler.py <program.bin>")
        sys.exit(1)

    bin_file = sys.argv[1]
    with open(bin_file, 'rb') as f:
        data = f.read()

    words = []
    for i in range(0, len(data), 4):
        chunk = data[i:i+4]
        if len(chunk) == 4:
            words.append(int.from_bytes(chunk, byteorder='big', signed=False))

    dis_lines = disassemble_program(words)
    for line in dis_lines:
        print(line)
