"""
SSX Silicon 1 (SSX-32) Instruction Set Architecture Definitions
Creator: Samin Sami (SS)
Architecture: 32-bit RISC/CISC Hybrid Processor
"""

# Number of general-purpose 32-bit registers
NUM_REGISTERS = 32

# Special Register Aliases
REG_ZERO = 0   # Hardwired zero (R0)
REG_FP   = 28  # Frame Pointer (R28)
REG_SP   = 29  # Stack Pointer (R29)
REG_LR   = 30  # Link Register / Return Address (R30)
REG_PC   = 31  # Program Counter alias (R31)

# Memory Map Configuration (32-bit address space, word-addressable in spreadsheet)
RAM_SIZE_WORDS    = 4096      # 4K 32-bit words (16 KB) for primary spreadsheet RAM
ROM_START_ADDR    = 0x0000    # Start of executable code
RAM_START_ADDR    = 0x1000    # Data / Heap segment
STACK_START_ADDR  = 0x1FFF    # Stack grows downward from here
MMIO_START_ADDR   = 0x2000    # Memory-Mapped I/O registers
VRAM_START_ADDR   = 0x2400    # 32x32 Graphics Video RAM (1024 words)
VRAM_WIDTH        = 32
VRAM_HEIGHT       = 32

# MMIO Register Addresses
MMIO_SYS_CLOCK    = 0x2000    # Monotonic cycle clock
MMIO_SYS_RANDOM   = 0x2001    # Pseudo-random number generator
MMIO_SYS_INPUT    = 0x2002    # Keyboard / controller input buffer
MMIO_SYS_OUTPUT   = 0x2003    # Seven-segment / Hex status display
MMIO_SYS_TIMER    = 0x2004    # Millisecond system timer

# Instruction Opcodes (8-bit)
OPCODES = {
    # Control & System (0x00 - 0x0F)
    'NOP':      0x00,
    'HLT':      0x01,
    'RESET':    0x02,
    'SYS':      0x03,
    'CLC':      0x04,
    'STC':      0x05,

    # Register & Memory Transfer (0x10 - 0x1F)
    'MOV':      0x10,
    'LOAD':     0x11,
    'STORE':    0x12,
    'LOADI':    0x13,
    'STOREI':   0x14,
    'PUSH':     0x15,
    'POP':      0x16,
    'LOADOFF':  0x17,
    'STOREOFF': 0x18,

    # Arithmetic Operations (0x20 - 0x2F)
    'ADD':      0x20,
    'ADDI':     0x21,
    'SUB':      0x22,
    'SUBI':     0x23,
    'MUL':      0x24,
    'DIV':      0x25,
    'MOD':      0x26,
    'INC':      0x27,
    'DEC':      0x28,
    'NEG':      0x29,

    # Bitwise & Shift Operations (0x30 - 0x3F)
    'AND':      0x30,
    'ANDI':     0x31,
    'OR':       0x32,
    'ORI':      0x33,
    'XOR':      0x34,
    'XORI':     0x35,
    'NOT':      0x36,
    'SHL':      0x37,
    'SHR':      0x38,
    'SAR':      0x39,
    'ROL':      0x3A,
    'ROR':      0x3B,

    # Comparison & Tests (0x40 - 0x4F)
    'CMP':      0x40,
    'CMPI':     0x41,
    'TST':      0x42,

    # Branch & Subroutine (0x50 - 0x5F)
    'JMP':      0x50,
    'JE':       0x51,  # Also JZ
    'JZ':       0x51,
    'JNE':      0x52,  # Also JNZ
    'JNZ':      0x52,
    'JL':       0x53,
    'JLE':      0x54,
    'JG':       0x55,
    'JGE':      0x56,
    'JC':       0x57,
    'JNC':      0x58,
    'CALL':     0x59,
    'RET':      0x5A,

    # Display & Graphics MMIO (0x60 - 0x6F)
    'OUT':      0x60,
    'IN':       0x61,
    'VSET':     0x62,
    'VCLR':     0x63,
}

OPCODE_NAMES = {v: k for k, v in OPCODES.items() if k not in ('JZ', 'JNZ')}

# Two-word instructions (followed by 32-bit immediate in memory)
TWO_WORD_OPCODES = {
    OPCODES['LOADI'],
    OPCODES['STOREI'],
    OPCODES['JMP'],
    OPCODES['JE'],
    OPCODES['JNE'],
    OPCODES['JL'],
    OPCODES['JLE'],
    OPCODES['JG'],
    OPCODES['JGE'],
    OPCODES['JC'],
    OPCODES['JNC'],
    OPCODES['CALL'],
}

# Register name mapping: R0 - R31, and aliases
REGISTER_MAP = {}
for i in range(32):
    REGISTER_MAP[f'R{i}'] = i
    REGISTER_MAP[f'r{i}'] = i

# Common RISC Aliases
REGISTER_MAP['ZERO'] = 0
REGISTER_MAP['ZR']   = 0
REGISTER_MAP['FP']   = 28
REGISTER_MAP['SP']   = 29
REGISTER_MAP['LR']   = 30
REGISTER_MAP['PC']   = 31

# Status Flag Bit Masks
FLAG_ZF = 0x01  # Zero Flag
FLAG_CF = 0x02  # Carry Flag
FLAG_SF = 0x04  # Sign Flag
FLAG_OF = 0x08  # Overflow Flag

def pack_instruction(opcode: int, rd: int = 0, rs1: int = 0, rs2: int = 0, imm9: int = 0) -> int:
    """Pack an instruction into a 32-bit unsigned integer."""
    op = (opcode & 0xFF) << 24
    d  = (rd & 0x1F) << 19
    s1 = (rs1 & 0x1F) << 14
    s2 = (rs2 & 0x1F) << 9
    im = (imm9 & 0x1FF)
    return (op | d | s1 | s2 | im) & 0xFFFFFFFF

def unpack_instruction(word: int):
    """Unpack a 32-bit unsigned integer into instruction fields."""
    opcode = (word >> 24) & 0xFF
    rd     = (word >> 19) & 0x1F
    rs1    = (word >> 14) & 0x1F
    rs2    = (word >> 9)  & 0x1F
    imm9   = word & 0x1FF
    # Sign-extend 9-bit immediate if bit 8 is set
    if imm9 & 0x100:
        imm9_signed = imm9 - 0x200
    else:
        imm9_signed = imm9
    return opcode, rd, rs1, rs2, imm9, imm9_signed
