"""
SSX Silicon 1 (SSX-32) Two-Pass Assembler
Creator: Samin Sami (SS)
Translates SSX-32 assembly source files into verified 32-bit machine code.
"""

import sys
import os
import re
from typing import List, Dict, Tuple, Optional

try:
    from ssx_isa import (
        OPCODES, TWO_WORD_OPCODES, REGISTER_MAP,
        pack_instruction, NUM_REGISTERS
    )
except ImportError:
    from compiler.ssx_isa import (
        OPCODES, TWO_WORD_OPCODES, REGISTER_MAP,
        pack_instruction, NUM_REGISTERS
    )

class AssemblerError(Exception):
    def __init__(self, message: str, line_num: int = 0, line_text: str = ""):
        self.message = message
        self.line_num = line_num
        self.line_text = line_text
        super().__init__(f"Line {line_num}: {message} -> '{line_text.strip()}'")

class SSXAssembler:
    def __init__(self):
        self.symbols: Dict[str, int] = {}
        self.constants: Dict[str, int] = {}
        self.machine_code: List[int] = []
        self.listing: List[str] = []
        self.entry_point: int = 0

    def parse_literal(self, token: str) -> int:
        """Parse numbers in decimal, hex ($ or 0x), or binary (% or 0b)."""
        token = token.strip()
        if token.startswith('#'):
            token = token[1:]
        if token.startswith('$'):
            return int(token[1:], 16)
        if token.startswith('0x') or token.startswith('0X'):
            return int(token, 16)
        if token.startswith('%'):
            return int(token[1:], 2)
        if token.startswith('0b') or token.startswith('0B'):
            return int(token, 2)
        if token in self.constants:
            return self.constants[token]
        return int(token)

    def parse_register(self, token: str, line_num: int, line_text: str) -> int:
        token = token.strip().rstrip(',')
        if token in REGISTER_MAP:
            return REGISTER_MAP[token]
        raise AssemblerError(f"Invalid register name '{token}'", line_num, line_text)

    def assemble(self, source_text: str) -> List[int]:
        lines = source_text.splitlines()
        
        # -------------------------------------------------------------
        # PASS 1: Identify labels, constants, directives, and addresses
        # -------------------------------------------------------------
        current_addr = 0
        self.symbols.clear()
        self.constants.clear()
        cleaned_lines: List[Tuple[int, str, str]] = [] # (line_num, line_clean, original)

        for line_num, raw_line in enumerate(lines, start=1):
            # Strip comments
            comment_idx = raw_line.find(';')
            line = raw_line if comment_idx == -1 else raw_line[:comment_idx]
            line = line.strip()

            if not line:
                continue

            # Check for label definition
            label_match = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)\s*:(.*)$', line)
            if label_match:
                label_name = label_match.group(1).upper()
                if label_name in self.symbols:
                    raise AssemblerError(f"Duplicate label '{label_name}'", line_num, raw_line)
                self.symbols[label_name] = current_addr
                remainder = label_match.group(2).strip()
                if remainder:
                    cleaned_lines.append((line_num, remainder, raw_line))
                    current_addr += self._estimate_instruction_size(remainder, line_num, raw_line)
                continue

            # Check for EQU / CONST directive
            equ_match = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)\s+(EQU|\.CONST|=)\s+(.+)$', line, re.IGNORECASE)
            if equ_match:
                const_name = equ_match.group(1).upper()
                val_str = equ_match.group(3).strip()
                val = self.parse_literal(val_str)
                self.constants[const_name] = val
                continue

            # Directives
            parts = line.split(None, 1)
            directive = parts[0].upper()
            if directive == '.ORG':
                target_addr = self.parse_literal(parts[1])
                if target_addr < current_addr:
                    raise AssemblerError(f".ORG address {target_addr:#x} is below current address {current_addr:#x}", line_num, raw_line)
                current_addr = target_addr
                cleaned_lines.append((line_num, line, raw_line))
                continue
            elif directive == '.WORD':
                elements = [e.strip() for e in parts[1].split(',')]
                current_addr += len(elements)
                cleaned_lines.append((line_num, line, raw_line))
                continue
            elif directive == '.SPACE':
                count = self.parse_literal(parts[1])
                current_addr += count
                cleaned_lines.append((line_num, line, raw_line))
                continue
            elif directive in ('.DATA', '.CODE'):
                # Section marker, does not advance address
                continue

            # Normal instruction
            cleaned_lines.append((line_num, line, raw_line))
            current_addr += self._estimate_instruction_size(line, line_num, raw_line)

        # -------------------------------------------------------------
        # PASS 2: Encode instructions and resolve symbols
        # -------------------------------------------------------------
        self.machine_code = []
        self.listing = []
        current_addr = 0

        for line_num, line, original in cleaned_lines:
            tokens = [t.strip().rstrip(',') for t in line.split()]
            if not tokens:
                continue

            mnemonic = tokens[0].upper()

            # Handle .ORG
            if mnemonic == '.ORG':
                target_addr = self.parse_literal(tokens[1])
                while current_addr < target_addr:
                    self.machine_code.append(0)
                    self.listing.append(f"{current_addr:04X}: 00000000   (padding)")
                    current_addr += 1
                continue

            # Handle .WORD
            if mnemonic == '.WORD':
                items = [it.strip() for it in line[len('.WORD'):].split(',')]
                for item in items:
                    val = self._resolve_value(item, line_num, original)
                    val32 = val & 0xFFFFFFFF
                    self.machine_code.append(val32)
                    self.listing.append(f"{current_addr:04X}: {val32:08X}   .WORD {item}")
                    current_addr += 1
                continue

            # Handle .SPACE
            if mnemonic == '.SPACE':
                count = self.parse_literal(tokens[1])
                for _ in range(count):
                    self.machine_code.append(0)
                    self.listing.append(f"{current_addr:04X}: 00000000   .SPACE 1")
                    current_addr += 1
                continue

            if mnemonic not in OPCODES:
                raise AssemblerError(f"Unknown instruction '{mnemonic}'", line_num, original)

            opcode = OPCODES[mnemonic]
            encoded_words = self._encode_instruction(mnemonic, opcode, tokens[1:], line_num, original, current_addr)

            for i, word in enumerate(encoded_words):
                w32 = word & 0xFFFFFFFF
                self.machine_code.append(w32)
                if i == 0:
                    self.listing.append(f"{current_addr:04X}: {w32:08X}   {line}")
                else:
                    self.listing.append(f"{current_addr:04X}: {w32:08X}   (imm32)")
                current_addr += 1

        return self.machine_code

    def _estimate_instruction_size(self, line: str, line_num: int, raw_line: str) -> int:
        tokens = line.split()
        if not tokens:
            return 0
        mnemonic = tokens[0].upper()
        if mnemonic in ('.DATA', '.CODE'):
            return 0
        if mnemonic == '.WORD':
            return len(line[len('.WORD'):].split(','))
        if mnemonic == '.SPACE':
            return self.parse_literal(tokens[1])
        if mnemonic == '.ORG':
            return 0
        if mnemonic in OPCODES and OPCODES[mnemonic] in TWO_WORD_OPCODES:
            return 2
        return 1

    def _resolve_value(self, token: str, line_num: int, original: str) -> int:
        token = token.strip().rstrip(',')
        if token.upper() in self.symbols:
            return self.symbols[token.upper()]
        if token.upper() in self.constants:
            return self.constants[token.upper()]
        try:
            return self.parse_literal(token)
        except ValueError:
            raise AssemblerError(f"Undefined symbol or invalid literal '{token}'", line_num, original)

    def _encode_instruction(self, mnemonic: str, opcode: int, args: List[str], line_num: int, original: str, current_addr: int) -> List[int]:
        # Clean commas
        clean_args = [a.rstrip(',') for a in args if a.strip()]

        # System instructions with 0 operands
        if mnemonic in ('NOP', 'HLT', 'RESET', 'CLC', 'STC', 'RET'):
            return [pack_instruction(opcode)]

        # System call
        if mnemonic == 'SYS':
            code = self.parse_literal(clean_args[0]) if clean_args else 0
            return [pack_instruction(opcode, imm9=code)]

        # Two-word immediate loads & stores
        if mnemonic == 'LOADI':
            if len(clean_args) < 2:
                raise AssemblerError("LOADI expects: LOADI Rd, #imm32", line_num, original)
            rd = self.parse_register(clean_args[0], line_num, original)
            val = self._resolve_value(clean_args[1], line_num, original)
            return [pack_instruction(opcode, rd=rd), val & 0xFFFFFFFF]

        if mnemonic == 'STOREI':
            if len(clean_args) < 2:
                raise AssemblerError("STOREI expects: STOREI #imm32, [Rd]", line_num, original)
            val = self._resolve_value(clean_args[0], line_num, original)
            rd_token = clean_args[1].strip('[]')
            rd = self.parse_register(rd_token, line_num, original)
            return [pack_instruction(opcode, rd=rd), val & 0xFFFFFFFF]

        # Branches and jumps (2 words: header + 32-bit target)
        if mnemonic in ('JMP', 'JE', 'JZ', 'JNE', 'JNZ', 'JL', 'JLE', 'JG', 'JGE', 'JC', 'JNC', 'CALL'):
            if len(clean_args) < 1:
                raise AssemblerError(f"{mnemonic} expects target address or label", line_num, original)
            target = self._resolve_value(clean_args[0], line_num, original)
            return [pack_instruction(opcode), target & 0xFFFFFFFF]

        # Stack instructions
        if mnemonic == 'PUSH':
            rs = self.parse_register(clean_args[0], line_num, original)
            return [pack_instruction(opcode, rs1=rs)]

        if mnemonic == 'POP':
            rd = self.parse_register(clean_args[0], line_num, original)
            return [pack_instruction(opcode, rd=rd)]

        # Register-to-register moves and loads/stores
        if mnemonic == 'MOV':
            rd = self.parse_register(clean_args[0], line_num, original)
            rs = self.parse_register(clean_args[1], line_num, original)
            return [pack_instruction(opcode, rd=rd, rs1=rs)]

        if mnemonic == 'LOAD':
            rd = self.parse_register(clean_args[0], line_num, original)
            rs_token = clean_args[1].strip('[]')
            rs = self.parse_register(rs_token, line_num, original)
            return [pack_instruction(opcode, rd=rd, rs1=rs)]

        if mnemonic == 'STORE':
            rs = self.parse_register(clean_args[0], line_num, original)
            rd_token = clean_args[1].strip('[]')
            rd = self.parse_register(rd_token, line_num, original)
            return [pack_instruction(opcode, rd=rd, rs1=rs)]

        # Single register math
        if mnemonic in ('INC', 'DEC', 'NEG', 'NOT'):
            rd = self.parse_register(clean_args[0], line_num, original)
            return [pack_instruction(opcode, rd=rd)]

        # Three-operand arithmetic and logic: Rd, Rs1, Rs2
        if mnemonic in ('ADD', 'SUB', 'MUL', 'DIV', 'MOD', 'AND', 'OR', 'XOR'):
            if len(clean_args) < 3:
                # Allow two-operand form: ADD Rd, Rs -> Rd = Rd + Rs
                if len(clean_args) == 2:
                    rd = self.parse_register(clean_args[0], line_num, original)
                    rs2 = self.parse_register(clean_args[1], line_num, original)
                    return [pack_instruction(opcode, rd=rd, rs1=rd, rs2=rs2)]
                raise AssemblerError(f"{mnemonic} expects Rd, Rs1, Rs2", line_num, original)
            rd = self.parse_register(clean_args[0], line_num, original)
            rs1 = self.parse_register(clean_args[1], line_num, original)
            rs2 = self.parse_register(clean_args[2], line_num, original)
            return [pack_instruction(opcode, rd=rd, rs1=rs1, rs2=rs2)]

        # Immediate arithmetic: Rd, Rs1, #imm9
        if mnemonic in ('ADDI', 'SUBI', 'ANDI', 'ORI', 'XORI'):
            if len(clean_args) == 2:
                rd = self.parse_register(clean_args[0], line_num, original)
                imm = self._resolve_value(clean_args[1], line_num, original)
                return [pack_instruction(opcode, rd=rd, rs1=rd, imm9=imm & 0x1FF)]
            elif len(clean_args) >= 3:
                rd = self.parse_register(clean_args[0], line_num, original)
                rs1 = self.parse_register(clean_args[1], line_num, original)
                imm = self._resolve_value(clean_args[2], line_num, original)
                return [pack_instruction(opcode, rd=rd, rs1=rs1, imm9=imm & 0x1FF)]

        # Shifts and Rotates: Rd, Rs, #shift
        if mnemonic in ('SHL', 'SHR', 'SAR', 'ROL', 'ROR'):
            if len(clean_args) == 2:
                rd = self.parse_register(clean_args[0], line_num, original)
                shift = self._resolve_value(clean_args[1], line_num, original)
                return [pack_instruction(opcode, rd=rd, rs1=rd, imm9=shift & 0x1F)]
            elif len(clean_args) >= 3:
                rd = self.parse_register(clean_args[0], line_num, original)
                rs = self.parse_register(clean_args[1], line_num, original)
                shift = self._resolve_value(clean_args[2], line_num, original)
                return [pack_instruction(opcode, rd=rd, rs1=rs, imm9=shift & 0x1F)]

        # Compare instructions
        if mnemonic in ('CMP', 'TST'):
            rs1 = self.parse_register(clean_args[0], line_num, original)
            rs2 = self.parse_register(clean_args[1], line_num, original)
            return [pack_instruction(opcode, rs1=rs1, rs2=rs2)]

        if mnemonic == 'CMPI':
            rs1 = self.parse_register(clean_args[0], line_num, original)
            imm = self._resolve_value(clean_args[1], line_num, original)
            return [pack_instruction(opcode, rs1=rs1, imm9=imm & 0x1FF)]

        # I/O instructions
        if mnemonic == 'OUT':
            # OUT port, Rs
            port = self._resolve_value(clean_args[0], line_num, original)
            rs = self.parse_register(clean_args[1], line_num, original)
            return [pack_instruction(opcode, rs1=rs, imm9=port & 0x1FF)]

        if mnemonic == 'IN':
            # IN Rd, port
            rd = self.parse_register(clean_args[0], line_num, original)
            port = self._resolve_value(clean_args[1], line_num, original)
            return [pack_instruction(opcode, rd=rd, imm9=port & 0x1FF)]

        # Display instructions
        if mnemonic == 'VSET':
            # VSET Rx, Ry, Rcolor
            rx = self.parse_register(clean_args[0], line_num, original)
            ry = self.parse_register(clean_args[1], line_num, original)
            rc = self.parse_register(clean_args[2], line_num, original)
            return [pack_instruction(opcode, rd=rc, rs1=rx, rs2=ry)]

        if mnemonic == 'VCLR':
            # VCLR Rcolor or #imm
            if clean_args[0].upper() in REGISTER_MAP:
                rc = self.parse_register(clean_args[0], line_num, original)
                return [pack_instruction(opcode, rd=rc)]
            else:
                col = self.parse_literal(clean_args[0])
                return [pack_instruction(opcode, imm9=col & 0xFF)]

        raise AssemblerError(f"Unhandled instruction formatting '{mnemonic}'", line_num, original)

    def write_binary(self, filepath: str):
        with open(filepath, 'wb') as f:
            for word in self.machine_code:
                f.write(word.to_bytes(4, byteorder='big', signed=False))

    def write_hex(self, filepath: str):
        with open(filepath, 'w') as f:
            for i, word in enumerate(self.machine_code):
                f.write(f"@{i:04X} {word:08X}\n")

    def write_listing(self, filepath: str):
        with open(filepath, 'w') as f:
            f.write(f"; SSX Silicon 1 Assembly Listing\n")
            f.write(f"; Total Words: {len(self.machine_code)}\n\n")
            for line in self.listing:
                f.write(line + "\n")

    def write_google_sheets_csv(self, filepath: str, cols: int = 16):
        """Write ROM in a 2D matrix format ready for copy-paste into Google Sheets."""
        with open(filepath, 'w') as f:
            for i in range(0, len(self.machine_code), cols):
                chunk = self.machine_code[i:i + cols]
                row_str = ",".join(f"0x{w:08X}" for w in chunk)
                f.write(row_str + "\n")

    def get_javascript_array(self) -> str:
        """Return machine code formatted as a JavaScript array for Google Apps Script."""
        items = [f"0x{w:08X}" for w in self.machine_code]
        lines = []
        for i in range(0, len(items), 8):
            lines.append("  " + ", ".join(items[i:i + 8]))
        return "[\n" + ",\n".join(lines) + "\n]"

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python ssx_assembler.py <program.ssx> [output_prefix]")
        sys.exit(1)

    src_file = sys.argv[1]
    out_prefix = sys.argv[2] if len(sys.argv) > 2 else os.path.splitext(src_file)[0]

    with open(src_file, 'r') as f:
        source = f.read()

    assembler = SSXAssembler()
    try:
        code = assembler.assemble(source)
        assembler.write_binary(out_prefix + ".bin")
        assembler.write_hex(out_prefix + ".hex")
        assembler.write_listing(out_prefix + ".lst")
        assembler.write_google_sheets_csv(out_prefix + "_sheets.csv")
        print(f"Assembly successful: {len(code)} 32-bit words assembled.")
        print(f"Outputs written: {out_prefix}.bin, .hex, .lst, _sheets.csv")
    except AssemblerError as e:
        print(f"Assembly Error: {e}")
        sys.exit(1)
