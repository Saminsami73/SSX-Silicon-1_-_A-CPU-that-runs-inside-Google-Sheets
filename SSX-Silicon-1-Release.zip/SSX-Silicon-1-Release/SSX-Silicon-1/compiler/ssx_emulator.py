"""
SSX Silicon 1 (SSX-32) Reference Emulator & Hardware Verifier
Creator: Samin Sami (SS)
Cycle-accurate 32-bit hardware execution simulator.
"""

import sys
import os
import random
from typing import List, Dict, Optional
try:
    from ssx_isa import (
        OPCODES, TWO_WORD_OPCODES, NUM_REGISTERS,
        FLAG_ZF, FLAG_CF, FLAG_SF, FLAG_OF,
        RAM_SIZE_WORDS, VRAM_START_ADDR, VRAM_WIDTH, VRAM_HEIGHT,
        MMIO_SYS_CLOCK, MMIO_SYS_RANDOM, MMIO_SYS_INPUT, MMIO_SYS_OUTPUT,
        unpack_instruction
    )
except ImportError:
    from compiler.ssx_isa import (
        OPCODES, TWO_WORD_OPCODES, NUM_REGISTERS,
        FLAG_ZF, FLAG_CF, FLAG_SF, FLAG_OF,
        RAM_SIZE_WORDS, VRAM_START_ADDR, VRAM_WIDTH, VRAM_HEIGHT,
        MMIO_SYS_CLOCK, MMIO_SYS_RANDOM, MMIO_SYS_INPUT, MMIO_SYS_OUTPUT,
        unpack_instruction
    )

class SSXEmulator:
    def __init__(self, memory_size: int = 65536):
        self.memory_size = memory_size
        self.memory = [0] * memory_size
        self.vram = [0] * (VRAM_WIDTH * VRAM_HEIGHT)
        self.registers = [0] * NUM_REGISTERS
        self.pc = 0
        self.flags = 0  # ZF, CF, SF, OF
        self.halted = False
        self.cycles = 0
        self.instructions_retired = 0
        self.io_output = 0
        self.io_input = 0

        # Initialize stack pointer to top of default stack region
        self.registers[29] = 0x3FFF  # SP

    def reset(self):
        self.registers = [0] * NUM_REGISTERS
        self.registers[29] = 0x3FFF  # SP
        self.pc = 0
        self.flags = 0
        self.halted = False
        self.cycles = 0
        self.instructions_retired = 0
        self.io_output = 0

    def load_program(self, machine_code: List[int], start_addr: int = 0):
        for i, word in enumerate(machine_code):
            addr = start_addr + i
            if addr < self.memory_size:
                self.memory[addr] = word & 0xFFFFFFFF
        self.pc = start_addr

    # --- Flag Helpers ---
    def set_flag(self, flag: int, value: bool):
        if value:
            self.flags |= flag
        else:
            self.flags &= ~flag

    def get_flag(self, flag: int) -> bool:
        return bool(self.flags & flag)

    def update_flags_arithmetic(self, result: int, op1: int, op2: int, is_sub: bool):
        """Update Zero, Carry, Sign, and Overflow flags for 32-bit operations."""
        val32 = result & 0xFFFFFFFF
        # ZF
        self.set_flag(FLAG_ZF, val32 == 0)
        # SF (bit 31)
        self.set_flag(FLAG_SF, bool(val32 & 0x80000000))
        # CF
        if not is_sub:
            self.set_flag(FLAG_CF, result > 0xFFFFFFFF)
        else:
            self.set_flag(FLAG_CF, op1 < op2)

        # OF: Signed 32-bit overflow
        s1 = op1 if op1 < 0x80000000 else op1 - 0x100000000
        s2 = op2 if op2 < 0x80000000 else op2 - 0x100000000
        if not is_sub:
            sres = s1 + s2
        else:
            sres = s1 - s2
        self.set_flag(FLAG_OF, sres < -2147483648 or sres > 2147483647)

    def update_flags_logic(self, val32: int):
        """Update ZF and SF for logical/shift operations."""
        v = val32 & 0xFFFFFFFF
        self.set_flag(FLAG_ZF, v == 0)
        self.set_flag(FLAG_SF, bool(v & 0x80000000))

    # --- Memory Access ---
    def read_mem(self, addr: int) -> int:
        addr = addr & 0xFFFFFFFF
        # Check MMIO
        if addr == MMIO_SYS_CLOCK:
            return self.cycles & 0xFFFFFFFF
        if addr == MMIO_SYS_RANDOM:
            return random.randint(0, 0xFFFFFFFF)
        if addr == MMIO_SYS_INPUT:
            return self.io_input
        if addr == MMIO_SYS_OUTPUT:
            return self.io_output

        # VRAM check
        if VRAM_START_ADDR <= addr < (VRAM_START_ADDR + len(self.vram)):
            return self.vram[addr - VRAM_START_ADDR]

        if addr < self.memory_size:
            return self.memory[addr]
        return 0

    def write_mem(self, addr: int, val: int):
        addr = addr & 0xFFFFFFFF
        val = val & 0xFFFFFFFF
        # Check MMIO
        if addr == MMIO_SYS_OUTPUT:
            self.io_output = val
            return
        if addr == MMIO_SYS_INPUT:
            self.io_input = val
            return

        # VRAM check
        if VRAM_START_ADDR <= addr < (VRAM_START_ADDR + len(self.vram)):
            self.vram[addr - VRAM_START_ADDR] = val & 0xFF
            return

        if addr < self.memory_size:
            self.memory[addr] = val

    # --- Step One Instruction ---
    def step(self) -> bool:
        if self.halted:
            return False

        if self.pc >= self.memory_size:
            self.halted = True
            return False

        word = self.memory[self.pc]
        next_word = self.memory[self.pc + 1] if self.pc + 1 < self.memory_size else 0

        opcode, rd, rs1, rs2, imm9, imm9_signed = unpack_instruction(word)
        inst_len = 2 if opcode in TWO_WORD_OPCODES else 1
        target_pc = self.pc + inst_len
        self.cycles += 1

        # R0 is hardwired to 0
        self.registers[0] = 0

        # --- Execution Dispatch ---
        if opcode == 0x00:  # NOP
            pass

        elif opcode == 0x01:  # HLT
            self.halted = True
            return False

        elif opcode == 0x02:  # RESET
            self.reset()
            return True

        elif opcode == 0x03:  # SYS
            # System call
            pass

        elif opcode == 0x04:  # CLC
            self.set_flag(FLAG_CF, False)

        elif opcode == 0x05:  # STC
            self.set_flag(FLAG_CF, True)

        elif opcode == 0x10:  # MOV Rd, Rs
            if rd != 0:
                self.registers[rd] = self.registers[rs1]

        elif opcode == 0x11:  # LOAD Rd, [Rs]
            if rd != 0:
                addr = self.registers[rs1]
                self.registers[rd] = self.read_mem(addr)

        elif opcode == 0x12:  # STORE Rs, [Rd]
            addr = self.registers[rd]
            self.write_mem(addr, self.registers[rs1])

        elif opcode == 0x13:  # LOADI Rd, #imm32
            if rd != 0:
                self.registers[rd] = next_word & 0xFFFFFFFF

        elif opcode == 0x14:  # STOREI #imm32, [Rd]
            addr = self.registers[rd]
            self.write_mem(addr, next_word)

        elif opcode == 0x15:  # PUSH Rs
            sp = self.registers[29]
            sp = (sp - 1) & 0xFFFFFFFF
            self.registers[29] = sp
            self.write_mem(sp, self.registers[rs1])

        elif opcode == 0x16:  # POP Rd
            sp = self.registers[29]
            val = self.read_mem(sp)
            self.registers[29] = (sp + 1) & 0xFFFFFFFF
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x20:  # ADD Rd, Rs1, Rs2
            a = self.registers[rs1]
            b = self.registers[rs2]
            res = a + b
            self.update_flags_arithmetic(res, a, b, is_sub=False)
            if rd != 0:
                self.registers[rd] = res & 0xFFFFFFFF

        elif opcode == 0x21:  # ADDI Rd, Rs1, #imm9
            a = self.registers[rs1]
            b = imm9_signed & 0xFFFFFFFF
            res = a + imm9_signed
            self.update_flags_arithmetic(res, a, b, is_sub=False)
            if rd != 0:
                self.registers[rd] = res & 0xFFFFFFFF

        elif opcode == 0x22:  # SUB Rd, Rs1, Rs2
            a = self.registers[rs1]
            b = self.registers[rs2]
            res = a - b
            self.update_flags_arithmetic(res, a, b, is_sub=True)
            if rd != 0:
                self.registers[rd] = res & 0xFFFFFFFF

        elif opcode == 0x23:  # SUBI Rd, Rs1, #imm9
            a = self.registers[rs1]
            b = imm9_signed & 0xFFFFFFFF
            res = a - imm9_signed
            self.update_flags_arithmetic(res, a, b, is_sub=True)
            if rd != 0:
                self.registers[rd] = res & 0xFFFFFFFF

        elif opcode == 0x24:  # MUL Rd, Rs1, Rs2
            a = self.registers[rs1]
            b = self.registers[rs2]
            prod = a * b
            low32 = prod & 0xFFFFFFFF
            high32 = (prod >> 32) & 0xFFFFFFFF
            self.update_flags_logic(low32)
            if rd != 0:
                self.registers[rd] = low32
            self.registers[27] = high32  # High 32 bits placed in R27

        elif opcode == 0x25:  # DIV Rd, Rs1, Rs2
            a = self.registers[rs1]
            b = self.registers[rs2]
            if b == 0:
                quot = 0xFFFFFFFF
                rem = 0
            else:
                quot = a // b
                rem = a % b
            self.update_flags_logic(quot)
            if rd != 0:
                self.registers[rd] = quot & 0xFFFFFFFF
            self.registers[27] = rem & 0xFFFFFFFF  # Remainder placed in R27

        elif opcode == 0x26:  # MOD Rd, Rs1, Rs2
            a = self.registers[rs1]
            b = self.registers[rs2]
            rem = a % b if b != 0 else 0
            self.update_flags_logic(rem)
            if rd != 0:
                self.registers[rd] = rem & 0xFFFFFFFF

        elif opcode == 0x27:  # INC Rd
            val = (self.registers[rd] + 1) & 0xFFFFFFFF
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x28:  # DEC Rd
            val = (self.registers[rd] - 1) & 0xFFFFFFFF
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x29:  # NEG Rd
            val = (-self.registers[rd]) & 0xFFFFFFFF
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x30:  # AND Rd, Rs1, Rs2
            val = self.registers[rs1] & self.registers[rs2]
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x31:  # ANDI Rd, Rs1, #imm9
            val = self.registers[rs1] & (imm9 & 0x1FF)
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x32:  # OR Rd, Rs1, Rs2
            val = self.registers[rs1] | self.registers[rs2]
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x33:  # ORI Rd, Rs1, #imm9
            val = self.registers[rs1] | (imm9 & 0x1FF)
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x34:  # XOR Rd, Rs1, Rs2
            val = self.registers[rs1] ^ self.registers[rs2]
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x35:  # XORI Rd, Rs1, #imm9
            val = self.registers[rs1] ^ (imm9 & 0x1FF)
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x36:  # NOT Rd
            val = (~self.registers[rd]) & 0xFFFFFFFF
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x37:  # SHL Rd, Rs, #shift
            shift = imm9 & 0x1F
            val = (self.registers[rs1] << shift) & 0xFFFFFFFF
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x38:  # SHR Rd, Rs, #shift (logical)
            shift = imm9 & 0x1F
            val = (self.registers[rs1] >> shift) & 0xFFFFFFFF
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x39:  # SAR Rd, Rs, #shift (arithmetic)
            shift = imm9 & 0x1F
            orig = self.registers[rs1]
            sign_bit = bool(orig & 0x80000000)
            val = (orig >> shift) & 0xFFFFFFFF
            if sign_bit and shift > 0:
                mask = ((1 << shift) - 1) << (32 - shift)
                val |= mask
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val & 0xFFFFFFFF

        elif opcode == 0x3A:  # ROL Rd, Rs, #shift
            shift = imm9 & 0x1F
            orig = self.registers[rs1]
            val = ((orig << shift) | (orig >> (32 - shift))) & 0xFFFFFFFF
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x3B:  # ROR Rd, Rs, #shift
            shift = imm9 & 0x1F
            orig = self.registers[rs1]
            val = ((orig >> shift) | (orig << (32 - shift))) & 0xFFFFFFFF
            self.update_flags_logic(val)
            if rd != 0:
                self.registers[rd] = val

        elif opcode == 0x40:  # CMP Rs1, Rs2
            a = self.registers[rs1]
            b = self.registers[rs2]
            res = a - b
            self.update_flags_arithmetic(res, a, b, is_sub=True)

        elif opcode == 0x41:  # CMPI Rs1, #imm9
            a = self.registers[rs1]
            b = imm9_signed & 0xFFFFFFFF
            res = a - imm9_signed
            self.update_flags_arithmetic(res, a, b, is_sub=True)

        elif opcode == 0x42:  # TST Rs1, Rs2
            val = self.registers[rs1] & self.registers[rs2]
            self.update_flags_logic(val)

        elif opcode == 0x50:  # JMP target
            target_pc = next_word

        elif opcode == 0x51:  # JE / JZ
            if self.get_flag(FLAG_ZF):
                target_pc = next_word

        elif opcode == 0x52:  # JNE / JNZ
            if not self.get_flag(FLAG_ZF):
                target_pc = next_word

        elif opcode == 0x53:  # JL (signed: SF != OF)
            if self.get_flag(FLAG_SF) != self.get_flag(FLAG_OF):
                target_pc = next_word

        elif opcode == 0x54:  # JLE (signed: ZF=1 or SF!=OF)
            if self.get_flag(FLAG_ZF) or (self.get_flag(FLAG_SF) != self.get_flag(FLAG_OF)):
                target_pc = next_word

        elif opcode == 0x55:  # JG (signed: ZF=0 and SF==OF)
            if not self.get_flag(FLAG_ZF) and (self.get_flag(FLAG_SF) == self.get_flag(FLAG_OF)):
                target_pc = next_word

        elif opcode == 0x56:  # JGE (signed: SF == OF)
            if self.get_flag(FLAG_SF) == self.get_flag(FLAG_OF):
                target_pc = next_word

        elif opcode == 0x57:  # JC (unsigned carry set: CF=1)
            if self.get_flag(FLAG_CF):
                target_pc = next_word

        elif opcode == 0x58:  # JNC (unsigned carry clear: CF=0)
            if not self.get_flag(FLAG_CF):
                target_pc = next_word

        elif opcode == 0x59:  # CALL target
            # Store return address on stack and in LR
            return_addr = self.pc + 2
            self.registers[30] = return_addr  # LR
            sp = (self.registers[29] - 1) & 0xFFFFFFFF
            self.registers[29] = sp
            self.write_mem(sp, return_addr)
            target_pc = next_word

        elif opcode == 0x5A:  # RET
            sp = self.registers[29]
            ret_addr = self.read_mem(sp)
            self.registers[29] = (sp + 1) & 0xFFFFFFFF
            target_pc = ret_addr

        elif opcode == 0x60:  # OUT port, Rs
            self.io_output = self.registers[rs1]

        elif opcode == 0x61:  # IN Rd, port
            if rd != 0:
                self.registers[rd] = self.io_input

        elif opcode == 0x62:  # VSET Rx, Ry, Rc
            x = self.registers[rs1] % VRAM_WIDTH
            y = self.registers[rs2] % VRAM_HEIGHT
            color = self.registers[rd] & 0x0F
            self.vram[y * VRAM_WIDTH + x] = color

        elif opcode == 0x63:  # VCLR Color
            color = (self.registers[rd] if rd != 0 else imm9) & 0x0F
            self.vram = [color] * (VRAM_WIDTH * VRAM_HEIGHT)

        # R0 hardwired to 0
        self.registers[0] = 0
        self.pc = target_pc
        self.instructions_retired += 1
        return True

    def run(self, max_cycles: int = 1000000) -> int:
        count = 0
        while not self.halted and count < max_cycles:
            if not self.step():
                break
            count += 1
        return count

    def print_state(self):
        print(f"Cycles: {self.cycles} | Retired: {self.instructions_retired} | PC: 0x{self.pc:04X} | Halted: {self.halted}")
        z = 1 if self.get_flag(FLAG_ZF) else 0
        c = 1 if self.get_flag(FLAG_CF) else 0
        s = 1 if self.get_flag(FLAG_SF) else 0
        o = 1 if self.get_flag(FLAG_OF) else 0
        print(f"FLAGS: [ZF={z} CF={c} SF={s} OF={o}]  (Raw=0x{self.flags:02X})")
        print("REGISTERS:")
        for row in range(4):
            line_parts = []
            for col in range(8):
                reg_idx = row * 8 + col
                line_parts.append(f"R{reg_idx:02d}:0x{self.registers[reg_idx]:08X}")
            print("  " + " ".join(line_parts))
