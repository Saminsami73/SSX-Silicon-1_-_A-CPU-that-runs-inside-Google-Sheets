/**
 * SSX Silicon 1 (SSX-32) - Google Apps Script Execution & Simulation Engine
 * Creator: Samin Sami (SS)
 * Architecture: 32-Bit Real Interactive Processor in Google Sheets
 * 
 * Provides interactive menus, step-by-step execution, high-speed emulation,
 * register updates, memory synchronization, and live 32x32 VRAM graphics rendering.
 */

// Palette mapping for 32x32 color graphics display
const SSX_COLOR_PALETTE = [
  "#0B0E14", // 0: Obsidian Black
  "#1D4ED8", // 1: Cobalt Blue
  "#059669", // 2: Forest Green
  "#06B6D4", // 3: Bright Cyan
  "#DC2626", // 4: Crimson Red
  "#9333EA", // 5: Royal Purple
  "#D97706", // 6: Warm Amber
  "#E2E8F0", // 7: Slate White
  "#475569", // 8: Dark Steel
  "#3B82F6", // 9: Electric Blue
  "#10B981", // 10: Emerald Green
  "#22D3EE", // 11: Neon Aqua
  "#EF4444", // 12: Bright Red
  "#F472B6", // 13: Neon Rose
  "#FBBF24", // 14: Cyber Gold
  "#FFFFFF"  // 15: Pure Bright White
];

// Pre-compiled Machine Code Programs (Bit-exact binaries from /programs)
const DEMO_PROGRAMS = {
  // 1. Hardware Self-Test Suite (146 words, Golden Signature 0xCAFEBABE)
  SELF_TEST: [
    0x13080000, 0x12345678, 0x10004000, 0x40000000, 0x52000000, 0x00000077, 0x21100000, 0x41008000,
    0x52000000, 0x00000077, 0x13180000, 0x7FFFFFFF, 0x13200000, 0x00000001, 0x2028C800, 0x41014000,
    0x51000000, 0x0000007A, 0x53000000, 0x00000016, 0x50000000, 0x0000007A, 0x22314800, 0x40018600,
    0x52000000, 0x0000007A, 0x13380000, 0x00010000, 0x13400000, 0x00020000, 0x2449D000, 0x41024000,
    0x52000000, 0x0000007D, 0x4106C002, 0x52000000, 0x0000007D, 0x13500000, 0x00000064, 0x13580000,
    0x00000007, 0x25629600, 0x4103000E, 0x52000000, 0x00000080, 0x4106C002, 0x52000000, 0x00000080,
    0x13680000, 0xF0F0F0F0, 0x13700000, 0x0F0F0F0F, 0x307B5C00, 0x4103C000, 0x52000000, 0x00000083,
    0x32835C00, 0x13880000, 0xFFFFFFFF, 0x40042200, 0x52000000, 0x00000083, 0x34936200, 0x40049C00,
    0x52000000, 0x00000083, 0x13980000, 0x80000001, 0x3AA4C001, 0x41050003, 0x52000000, 0x00000086,
    0x3BAD0001, 0x40056600, 0x52000000, 0x00000086, 0x13B00000, 0x00001500, 0x13B80000, 0xDEADBEEF,
    0x12B5C000, 0x11C58000, 0x40062E00, 0x52000000, 0x00000089, 0x14B00000, 0x12344321, 0x11CD8000,
    0x13D00000, 0x12344321, 0x40067400, 0x52000000, 0x00000089, 0x13080000, 0x55AA55AA, 0x15004000,
    0x13080000, 0x00000000, 0x16100000, 0x13180000, 0x55AA55AA, 0x40008600, 0x52000000, 0x0000008C,
    0x13200000, 0x0000000A, 0x59000000, 0x00000075, 0x41010014, 0x52000000, 0x0000008F, 0x13080000,
    0xCAFEBABE, 0x13100000, 0x00000000, 0x60004003, 0x01000000, 0x20210800, 0x5A000000, 0x13080000,
    0xEE000001, 0x01000000, 0x13080000, 0xEE000002, 0x01000000, 0x13080000, 0xEE000003, 0x01000000,
    0x13080000, 0xEE000004, 0x01000000, 0x13080000, 0xEE000005, 0x01000000, 0x13080000, 0xEE000006,
    0x01000000, 0x13080000, 0xEE000007, 0x01000000, 0x13080000, 0xEE000008, 0x01000000, 0x13080000,
    0xEE000009, 0x01000000
  ],

  // 2. 32-Bit Fibonacci (28 words, F(46) = 1,836,311,903)
  FIBONACCI: [
    0x13500000, 0x00001000, 0x13580000, 0x0000002F, 0x13080000, 0x00000000, 0x12504000, 0x21528001,
    0x13100000, 0x00000001, 0x12508000, 0x21528001, 0x13180000, 0x00000002, 0x4000D600, 0x56000000,
    0x00000019, 0x20204400, 0x12510000, 0x21528001, 0x10088000, 0x10110000, 0x2118C001, 0x50000000,
    0x0000000E, 0x10088000, 0x60004003, 0x01000000
  ],

  // 3. Prime Sieve of Eratosthenes (64 words, 25 Primes <= 100)
  PRIME_SIEVE: [
    0x13500000, 0x00001000, 0x13580000, 0x00000064, 0x13100000, 0x00000000, 0x13000000, 0x00000000,
    0x40009600, 0x55000000, 0x00000010, 0x20628400, 0x12600000, 0x21108001, 0x50000000, 0x00000008,
    0x13080000, 0x00000001, 0x12504000, 0x21628001, 0x12604000, 0x13100000, 0x00000002, 0x24188400,
    0x4000D600, 0x55000000, 0x0000002E, 0x20628400, 0x11230000, 0x41010000, 0x52000000, 0x0000002B,
    0x1028C000, 0x40015600, 0x55000000, 0x0000002B, 0x20628A00, 0x13300000, 0x00000001, 0x12618000,
    0x20294400, 0x50000000, 0x00000021, 0x21108001, 0x50000000, 0x00000017, 0x13080000, 0x00000000,
    0x13100000, 0x00000002, 0x40009600, 0x55000000, 0x0000003E, 0x20628400, 0x11230000, 0x41010000,
    0x52000000, 0x0000003B, 0x21084001, 0x21108001, 0x50000000, 0x00000032, 0x60004003, 0x01000000
  ],

  // 4. 3x3 Matrix Multiplication (133 words, Product [30, 24, 18, 84, 69, 54, 138, 114, 90])
  MATRIX_MULTIPLY: [
    0x13500000, 0x00001100, 0x13080000, 0x00000001, 0x12504000, 0x21528001, 0x13080000, 0x00000002,
    0x12504000, 0x21528001, 0x13080000, 0x00000003, 0x12504000, 0x21528001, 0x13080000, 0x00000004,
    0x12504000, 0x21528001, 0x13080000, 0x00000005, 0x12504000, 0x21528001, 0x13080000, 0x00000006,
    0x12504000, 0x21528001, 0x13080000, 0x00000007, 0x12504000, 0x21528001, 0x13080000, 0x00000008,
    0x12504000, 0x21528001, 0x13080000, 0x00000009, 0x12504000, 0x13500000, 0x00001120, 0x13080000,
    0x00000009, 0x12504000, 0x21528001, 0x13080000, 0x00000008, 0x12504000, 0x21528001, 0x13080000,
    0x00000007, 0x12504000, 0x21528001, 0x13080000, 0x00000006, 0x12504000, 0x21528001, 0x13080000,
    0x00000005, 0x12504000, 0x21528001, 0x13080000, 0x00000004, 0x12504000, 0x21528001, 0x13080000,
    0x00000003, 0x12504000, 0x21528001, 0x13080000, 0x00000002, 0x12504000, 0x21528001, 0x13080000,
    0x00000001, 0x12504000, 0x13A00000, 0x00000000, 0x41050003, 0x56000000, 0x0000007C, 0x13A80000,
    0x00000000, 0x41054003, 0x56000000, 0x00000079, 0x13B00000, 0x00000000, 0x13B80000, 0x00000000,
    0x41058003, 0x56000000, 0x0000006E, 0x13200000, 0x00000003, 0x242D0800, 0x20296C00, 0x13500000,
    0x00001100, 0x20528A00, 0x11328000, 0x243D8800, 0x2039EA00, 0x13580000, 0x00001120, 0x205ACE00,
    0x1142C000, 0x24499000, 0x20BDD200, 0x21B58001, 0x50000000, 0x00000058, 0x13200000, 0x00000003,
    0x242D0800, 0x20296A00, 0x13600000, 0x00001140, 0x20630A00, 0x1265C000, 0x21AD4001, 0x50000000,
    0x00000051, 0x21A50001, 0x50000000, 0x0000004C, 0x13600000, 0x00001140, 0x110B0000, 0x21630004,
    0x11130000, 0x21630004, 0x111B0000, 0x60008003, 0x01000000
  ],

  // 5. 32x32 Graphics Rendering (87 words, 232 Pixels in VRAM at 0x2400)
  GRAPHICS_DEMO: [
    0x63000000, 0x13080000, 0x00000000, 0x13100000, 0x00000003, 0x13180000, 0x00000000, 0x13200000,
    0x0000001F, 0x41004020, 0x56000000, 0x00000011, 0x62104600, 0x62104800, 0x21084001, 0x50000000,
    0x00000009, 0x13180000, 0x00000000, 0x13080000, 0x00000000, 0x13280000, 0x0000001F, 0x4100C020,
    0x56000000, 0x0000001F, 0x62104600, 0x62114600, 0x2118C001, 0x50000000, 0x00000017, 0x13080000,
    0x00000001, 0x13100000, 0x00000006, 0x4100401F, 0x56000000, 0x0000002E, 0x62104200, 0x13200000,
    0x0000001F, 0x22210200, 0x62104800, 0x21084001, 0x50000000, 0x00000023, 0x13100000, 0x0000000A,
    0x13180000, 0x0000000C, 0x4100C014, 0x56000000, 0x00000041, 0x13080000, 0x0000000C, 0x41004014,
    0x56000000, 0x0000003E, 0x62104600, 0x21084001, 0x50000000, 0x00000037, 0x2118C001, 0x50000000,
    0x00000032, 0x13100000, 0x0000000F, 0x13080000, 0x0000000F, 0x13180000, 0x0000000F, 0x62104600,
    0x13180000, 0x00000010, 0x62104600, 0x13080000, 0x00000010, 0x13180000, 0x0000000F, 0x62104600,
    0x13180000, 0x00000010, 0x62104600, 0x13080000, 0x000003E8, 0x60004003, 0x01000000
  ]
};

/**
 * Creates custom Google Sheets menu when workbook is opened.
 */
function onOpen() {
  const ui = SpreadsheetApp.getUi();
  ui.createMenu("SSX Silicon 1")
    .addItem("Step Clock (1 Cycle)", "ssxStepClock")
    .addItem("Step 10 Cycles", "ssxStep10Cycles")
    .addItem("Step 100 Cycles", "ssxStep100Cycles")
    .addItem("Run Program (Continuous)", "ssxRunContinuous")
    .addSeparator()
    .addItem("Reset CPU (PC = 0)", "ssxResetCpu")
    .addItem("Clear RAM & Cache", "ssxClearRam")
    .addSeparator()
    .addSubMenu(ui.createMenu("Load Program")
      .addItem("1. Hardware Self-Test (Golden 0xCAFEBABE)", "ssxLoadSelfTest")
      .addItem("2. 32-Bit Fibonacci (46 Terms)", "ssxLoadFibonacci")
      .addItem("3. Prime Sieve (Eratosthenes)", "ssxLoadPrimeSieve")
      .addItem("4. 3x3 Matrix Multiplication", "ssxLoadMatrixMultiply")
      .addItem("5. 32x32 Graphics Rendering", "ssxLoadGraphicsDemo"))
    .addSeparator()
    .addItem("Benchmark CPU Speed (IPS)", "ssxBenchmark")
    .addItem("About SSX Silicon 1", "ssxShowAbout")
    .addToUi();
}

/**
 * Reads the current CPU state from sheets.
 */
function getCpuState() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const dash = ss.getSheetByName("CONTROL_DASHBOARD") || ss.getSheetByName("DASHBOARD");
  const regSheet = ss.getSheetByName("REGISTERS_32");
  const ramSheet = ss.getSheetByName("RAM_MEMORY");
  const romSheet = ss.getSheetByName("ROM_STORAGE");
  const vramSheet = ss.getSheetByName("DISPLAY_SCREEN");

  if (!dash || !regSheet || !romSheet) {
    throw new Error("Required CPU sheets not found.");
  }

  const rawPc = dash.getRange("D6").getValue();
  let pc = 0;
  if (typeof rawPc === "number") {
    pc = rawPc;
  } else if (typeof rawPc === "string" && rawPc.startsWith("0x")) {
    pc = parseInt(rawPc, 16) || 0;
  } else {
    pc = parseInt(rawPc) || 0;
  }

  const cycles = parseInt(dash.getRange("D8").getValue()) || 0;
  const flags = parseInt(dash.getRange("D10").getValue(), 16) || 0;
  const halted = dash.getRange("D12").getValue() === "HALTED";

  // Read all 32 registers
  const registers = [];
  const rawRegs = regSheet.getRange("C4:C35").getValues();
  for (let i = 0; i < 32; i++) {
    let val = rawRegs[i][0];
    if (typeof val === "string" && val.startsWith("0x")) {
      registers.push(parseInt(val, 16) >>> 0);
    } else {
      registers.push((Number(val) || 0) >>> 0);
    }
  }

  return { ss, dash, regSheet, ramSheet, romSheet, vramSheet, pc, cycles, flags, halted, registers };
}

/**
 * Writes updated CPU state to DASHBOARD and REGISTERS sheets.
 */
function commitCpuState(state, modifiedRam, modifiedVram) {
  const { dash, regSheet, ramSheet, vramSheet, pc, cycles, flags, halted, registers } = state;
  
  // Dashboard indicators
  dash.getRange("D6").setValue("0x" + pc.toString(16).toUpperCase().padStart(4, "0"));
  dash.getRange("D8").setValue(cycles);
  dash.getRange("D10").setValue("0x" + flags.toString(16).toUpperCase().padStart(2, "0"));
  dash.getRange("D12").setValue(halted ? "HALTED" : "RUNNING");

  const zf = (flags & 1) ? "1" : "0";
  const cf = (flags & 2) ? "1" : "0";
  const sf = (flags & 4) ? "1" : "0";
  const of = (flags & 8) ? "1" : "0";
  dash.getRange("F10").setValue(`[ZF:${zf} CF:${cf} SF:${sf} OF:${of}]`);

  // Write registers (C4:C35) in one batch
  const regData = [];
  for (let i = 0; i < 32; i++) {
    regData.push(["0x" + (registers[i] >>> 0).toString(16).toUpperCase().padStart(8, "0")]);
  }
  regSheet.getRange("C4:C35").setValues(regData);

  // Sync modified RAM words to RAM_MEMORY sheet
  if (ramSheet && modifiedRam && modifiedRam.size > 0) {
    modifiedRam.forEach((val, addr) => {
      let offset = -1;
      if (addr >= 0x1000 && addr < 0x2000) {
        offset = addr - 0x1000;
      } else if (addr < 4096) {
        offset = addr;
      }
      if (offset >= 0 && offset < 4096) {
        const r = Math.floor(offset / 16) + 2;
        const c = (offset % 16) + 2;
        ramSheet.getRange(r, c).setValue("0x" + (val >>> 0).toString(16).toUpperCase().padStart(8, "0"));
      }
    });
  }

  // Sync modified pixels to DISPLAY_SCREEN sheet
  if (vramSheet && modifiedVram && modifiedVram.size > 0) {
    modifiedVram.forEach((colorIdx, coord) => {
      const parts = coord.split(",");
      const x = parseInt(parts[0]) + 2;
      const y = parseInt(parts[1]) + 2;
      vramSheet.getRange(y, x).setBackground(SSX_COLOR_PALETTE[colorIdx & 0x0F]);
    });
  }
}

/**
 * Steps CPU by N cycles with complete instruction dispatch.
 */
function ssxStepNCycles(maxSteps) {
  const state = getCpuState();
  if (state.halted) {
    SpreadsheetApp.getActiveSpreadsheet().toast("CPU is currently HALTED. Click Reset to restart.", "SSX Silicon 1", 3);
    return;
  }

  // Load ROM words (4096 words)
  const rawRom = state.romSheet.getRange(2, 2, 256, 16).getValues();
  const romWords = new Array(4096).fill(0);
  let p = 0;
  for (let r = 0; r < 256; r++) {
    for (let c = 0; c < 16; c++) {
      let val = rawRom[r][c];
      if (typeof val === "string" && val.startsWith("0x")) {
        romWords[p] = parseInt(val, 16) >>> 0;
      } else {
        romWords[p] = (Number(val) || 0) >>> 0;
      }
      p++;
    }
  }

  // Load RAM words (65536 words)
  const ramWords = new Array(65536).fill(0);
  if (state.ramSheet) {
    const rawRam = state.ramSheet.getRange(2, 2, 256, 16).getValues();
    p = 0;
    for (let r = 0; r < 256; r++) {
      for (let c = 0; c < 16; c++) {
        let val = rawRam[r][c];
        let numVal = 0;
        if (typeof val === "string" && val.startsWith("0x")) {
          numVal = parseInt(val, 16) >>> 0;
        } else {
          numVal = (Number(val) || 0) >>> 0;
        }
        ramWords[p] = numVal;
        ramWords[0x1000 + p] = numVal;
        p++;
      }
    }
  }

  const modifiedRam = new Map();
  const modifiedVram = new Map();

  function readMem(addr) {
    addr = addr >>> 0;
    if (addr === 0x2000) return state.cycles >>> 0;
    if (addr === 0x2001) return Math.floor(Math.random() * 0xFFFFFFFF) >>> 0;
    if (addr >= 0x2400 && addr < 0x2800) {
      const idx = addr - 0x2400;
      const x = idx % 32;
      const y = Math.floor(idx / 32);
      return modifiedVram.get(`${x},${y}`) || 0;
    }
    if (addr < 65536) {
      return modifiedRam.has(addr) ? modifiedRam.get(addr) : ramWords[addr];
    }
    return 0;
  }

  function writeMem(addr, val) {
    addr = addr >>> 0;
    val = val >>> 0;
    if (addr === 0x2003) {
      state.registers[1] = val; // Reflect to status monitor
      return;
    }
    if (addr >= 0x2400 && addr < 0x2800) {
      const idx = addr - 0x2400;
      const x = idx % 32;
      const y = Math.floor(idx / 32);
      modifiedVram.set(`${x},${y}`, val & 0x0F);
      return;
    }
    if (addr < 65536) {
      modifiedRam.set(addr, val);
      ramWords[addr] = val;
    }
  }

  let stepsTaken = 0;
  while (!state.halted && stepsTaken < maxSteps) {
    if (state.pc >= 4096) {
      state.halted = true;
      break;
    }

    const word = romWords[state.pc];
    const nextWord = (state.pc + 1 < 4096) ? romWords[state.pc + 1] : 0;
    
    const opcode = (word >>> 24) & 0xFF;
    const rd     = (word >>> 19) & 0x1F;
    const rs1    = (word >>> 14) & 0x1F;
    const rs2    = (word >>> 9)  & 0x1F;
    const imm9   = word & 0x1FF;
    const imm9_s = (imm9 & 0x100) ? (imm9 - 0x200) : imm9;

    const twoWordOps = [0x13, 0x14, 0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59];
    const instLen = twoWordOps.includes(opcode) ? 2 : 1;
    let targetPc = state.pc + instLen;

    state.cycles++;
    state.registers[0] = 0; // R0 hardwired zero

    // Dispatch table for all 36 SSX-32 instructions
    switch (opcode) {
      case 0x00: break; // NOP
      case 0x01: state.halted = true; break; // HLT
      case 0x02: state.pc = 0; break; // RESET
      case 0x03: break; // SYS
      case 0x04: state.flags &= ~2; break; // CLC
      case 0x05: state.flags |= 2; break; // STC

      // Data Movement & Stack
      case 0x10: // MOV
        if (rd !== 0) state.registers[rd] = state.registers[rs1];
        break;
      case 0x11: // LOAD Rd, [Rs]
        if (rd !== 0) state.registers[rd] = readMem(state.registers[rs1]);
        break;
      case 0x12: // STORE Rs, [Rd]
        writeMem(state.registers[rd], state.registers[rs1]);
        break;
      case 0x13: // LOADI Rd, #imm32
        if (rd !== 0) state.registers[rd] = nextWord >>> 0;
        break;
      case 0x14: // STOREI #imm32, [Rd]
        writeMem(state.registers[rd], nextWord);
        break;
      case 0x15: // PUSH Rs
        state.registers[29] = (state.registers[29] - 1) >>> 0;
        writeMem(state.registers[29], state.registers[rs1]);
        break;
      case 0x16: // POP Rd
        const popVal = readMem(state.registers[29]);
        state.registers[29] = (state.registers[29] + 1) >>> 0;
        if (rd !== 0) state.registers[rd] = popVal;
        break;

      // Arithmetic
      case 0x20: { // ADD
        const a = state.registers[rs1], b = state.registers[rs2];
        const res = (a + b) >>> 0;
        updateArithmeticFlags(state, a + b, a, b, false);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x21: { // ADDI
        const a = state.registers[rs1];
        const res = (a + imm9_s) >>> 0;
        updateArithmeticFlags(state, a + imm9_s, a, imm9_s >>> 0, false);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x22: { // SUB
        const a = state.registers[rs1], b = state.registers[rs2];
        const res = (a - b) >>> 0;
        updateArithmeticFlags(state, a - b, a, b, true);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x23: { // SUBI
        const a = state.registers[rs1];
        const res = (a - imm9_s) >>> 0;
        updateArithmeticFlags(state, a - imm9_s, a, imm9_s >>> 0, true);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x24: { // MUL
        const a = state.registers[rs1] >>> 0;
        const b = state.registers[rs2] >>> 0;
        const a_lo = a & 0xFFFF;
        const a_hi = a >>> 16;
        const b_lo = b & 0xFFFF;
        const b_hi = b >>> 16;

        const p0 = a_lo * b_lo;
        const p1 = a_lo * b_hi;
        const p2 = a_hi * b_lo;
        const p3 = a_hi * b_hi;

        const cy0 = Math.floor(p0 / 65536);
        const mid = p1 + p2 + cy0;
        const low = ((mid << 16) | (p0 & 0xFFFF)) >>> 0;
        const high = (p3 + Math.floor(mid / 65536)) >>> 0;

        if (rd !== 0) state.registers[rd] = low;
        state.registers[27] = high;
        updateLogicFlags(state, state.registers[rd]);
        break;
      }
      case 0x25: { // DIV
        const a = state.registers[rs1], b = state.registers[rs2];
        const quot = b === 0 ? 0xFFFFFFFF : Math.floor(a / b) >>> 0;
        const rem = b === 0 ? 0 : (a % b) >>> 0;
        if (rd !== 0) state.registers[rd] = quot;
        state.registers[27] = rem;
        updateLogicFlags(state, quot);
        break;
      }
      case 0x26: { // MOD
        const a = state.registers[rs1], b = state.registers[rs2];
        const rem = b === 0 ? 0 : (a % b) >>> 0;
        if (rd !== 0) state.registers[rd] = rem;
        updateLogicFlags(state, rem);
        break;
      }
      case 0x27: // INC
        if (rd !== 0) {
          state.registers[rd] = (state.registers[rd] + 1) >>> 0;
          updateLogicFlags(state, state.registers[rd]);
        }
        break;
      case 0x28: // DEC
        if (rd !== 0) {
          state.registers[rd] = (state.registers[rd] - 1) >>> 0;
          updateLogicFlags(state, state.registers[rd]);
        }
        break;
      case 0x29: // NEG
        if (rd !== 0) {
          state.registers[rd] = (-state.registers[rd]) >>> 0;
          updateLogicFlags(state, state.registers[rd]);
        }
        break;

      // Logic & Shifts
      case 0x30: { // AND
        const res = (state.registers[rs1] & state.registers[rs2]) >>> 0;
        updateLogicFlags(state, res);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x31: { // ANDI
        const res = (state.registers[rs1] & (imm9 & 0x1FF)) >>> 0;
        updateLogicFlags(state, res);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x32: { // OR
        const res = (state.registers[rs1] | state.registers[rs2]) >>> 0;
        updateLogicFlags(state, res);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x33: { // ORI
        const res = (state.registers[rs1] | (imm9 & 0x1FF)) >>> 0;
        updateLogicFlags(state, res);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x34: { // XOR
        const res = (state.registers[rs1] ^ state.registers[rs2]) >>> 0;
        updateLogicFlags(state, res);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x35: { // XORI
        const res = (state.registers[rs1] ^ (imm9 & 0x1FF)) >>> 0;
        updateLogicFlags(state, res);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x36: // NOT
        if (rd !== 0) {
          state.registers[rd] = (~state.registers[rd]) >>> 0;
          updateLogicFlags(state, state.registers[rd]);
        }
        break;
      case 0x37: { // SHL
        const shift = imm9 & 0x1F;
        const res = (state.registers[rs1] << shift) >>> 0;
        updateLogicFlags(state, res);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x38: { // SHR
        const shift = imm9 & 0x1F;
        const res = (state.registers[rs1] >>> shift) >>> 0;
        updateLogicFlags(state, res);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x39: { // SAR
        const shift = imm9 & 0x1F;
        const res = (state.registers[rs1] >> shift) >>> 0;
        updateLogicFlags(state, res);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x3A: { // ROL
        const shift = imm9 & 0x1F;
        const a = state.registers[rs1];
        const res = ((a << shift) | (a >>> (32 - shift))) >>> 0;
        updateLogicFlags(state, res);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }
      case 0x3B: { // ROR
        const shift = imm9 & 0x1F;
        const a = state.registers[rs1];
        const res = ((a >>> shift) | (a << (32 - shift))) >>> 0;
        updateLogicFlags(state, res);
        if (rd !== 0) state.registers[rd] = res;
        break;
      }

      // Comparison
      case 0x40: // CMP
        updateArithmeticFlags(state, state.registers[rs1] - state.registers[rs2], state.registers[rs1], state.registers[rs2], true);
        break;
      case 0x41: // CMPI
        updateArithmeticFlags(state, state.registers[rs1] - imm9_s, state.registers[rs1], imm9_s >>> 0, true);
        break;
      case 0x42: // TST
        updateLogicFlags(state, state.registers[rs1] & state.registers[rs2]);
        break;

      // Branches & Subroutines
      case 0x50: targetPc = nextWord; break; // JMP
      case 0x51: if (state.flags & 1) targetPc = nextWord; break; // JE / JZ
      case 0x52: if (!(state.flags & 1)) targetPc = nextWord; break; // JNE / JNZ
      case 0x53: { // JL (SF != OF)
        const sf = Boolean(state.flags & 4), of = Boolean(state.flags & 8);
        if (sf !== of) targetPc = nextWord;
        break;
      }
      case 0x54: { // JLE (ZF=1 or SF!=OF)
        const zf = Boolean(state.flags & 1), sf = Boolean(state.flags & 4), of = Boolean(state.flags & 8);
        if (zf || (sf !== of)) targetPc = nextWord;
        break;
      }
      case 0x55: { // JG (ZF=0 and SF==OF)
        const zf = Boolean(state.flags & 1), sf = Boolean(state.flags & 4), of = Boolean(state.flags & 8);
        if (!zf && (sf === of)) targetPc = nextWord;
        break;
      }
      case 0x56: { // JGE (SF == OF)
        const sf = Boolean(state.flags & 4), of = Boolean(state.flags & 8);
        if (sf === of) targetPc = nextWord;
        break;
      }
      case 0x57: if (state.flags & 2) targetPc = nextWord; break; // JC (CF=1)
      case 0x58: if (!(state.flags & 2)) targetPc = nextWord; break; // JNC (CF=0)
      case 0x59: { // CALL
        state.registers[30] = (state.pc + 2) >>> 0;
        state.registers[29] = (state.registers[29] - 1) >>> 0;
        writeMem(state.registers[29], state.registers[30]);
        targetPc = nextWord;
        break;
      }
      case 0x5A: { // RET
        targetPc = readMem(state.registers[29]);
        state.registers[29] = (state.registers[29] + 1) >>> 0;
        break;
      }

      // I/O & Graphics
      case 0x60: // OUT
        writeMem(imm9, state.registers[rs1]);
        break;
      case 0x61: // IN
        if (rd !== 0) state.registers[rd] = readMem(imm9);
        break;
      case 0x62: { // VSET
        const x = state.registers[rs1] % 32;
        const y = state.registers[rs2] % 32;
        const color = state.registers[rd] & 0x0F;
        modifiedVram.set(`${x},${y}`, color);
        break;
      }
      case 0x63: { // VCLR
        const color = (rd !== 0 ? state.registers[rd] : imm9) & 0x0F;
        for (let y = 0; y < 32; y++) {
          for (let x = 0; x < 32; x++) {
            modifiedVram.set(`${x},${y}`, color);
          }
        }
        break;
      }
    }

    state.registers[0] = 0;
    state.pc = targetPc >>> 0;
    stepsTaken++;
  }

  commitCpuState(state, modifiedRam, modifiedVram);
}

function updateArithmeticFlags(state, rawRes, op1, op2, isSub) {
  const val32 = rawRes >>> 0;
  let flags = 0;
  if (val32 === 0) flags |= 1; // ZF
  if (val32 & 0x80000000) flags |= 4; // SF
  if (!isSub) {
    if (rawRes > 0xFFFFFFFF) flags |= 2; // CF
  } else {
    if (op1 < op2) flags |= 2; // CF
  }
  // OF
  const s1 = op1 < 0x80000000 ? op1 : op1 - 0x100000000;
  const s2 = op2 < 0x80000000 ? op2 : op2 - 0x100000000;
  const sres = isSub ? (s1 - s2) : (s1 + s2);
  if (sres < -2147483648 || sres > 2147483647) flags |= 8; // OF
  state.flags = flags;
}

function updateLogicFlags(state, val32) {
  let flags = 0;
  if ((val32 >>> 0) === 0) flags |= 1;
  if (val32 & 0x80000000) flags |= 4;
  state.flags = flags;
}

// Menu Actions
function ssxStepClock() { ssxStepNCycles(1); }
function ssxStep10Cycles() { ssxStepNCycles(10); }
function ssxStep100Cycles() { ssxStepNCycles(100); }
function ssxRunContinuous() { ssxStepNCycles(50000); }

function ssxResetCpu() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const dash = ss.getSheetByName("CONTROL_DASHBOARD") || ss.getSheetByName("DASHBOARD");
  const regSheet = ss.getSheetByName("REGISTERS_32");

  dash.getRange("D6").setValue("0x0000");
  dash.getRange("D8").setValue(0);
  dash.getRange("D10").setValue("0x00");
  dash.getRange("D12").setValue("READY");
  dash.getRange("F10").setValue("[ZF:0 CF:0 SF:0 OF:0]");

  const zeroRegs = [];
  for (let i = 0; i < 32; i++) {
    zeroRegs.push([i === 29 ? "0x00003FFF" : "0x00000000"]);
  }
  regSheet.getRange("C4:C35").setValues(zeroRegs);
  ss.toast("SSX Silicon 1 Reset Complete. PC = 0x0000.", "SSX Silicon 1", 3);
}

function ssxClearRam() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const ramSheet = ss.getSheetByName("RAM_MEMORY");
  const vramSheet = ss.getSheetByName("DISPLAY_SCREEN");
  
  if (ramSheet) {
    const zeroGrid = [];
    for (let r = 0; r < 256; r++) {
      zeroGrid.push(new Array(16).fill("0x00000000"));
    }
    ramSheet.getRange(2, 2, 256, 16).setValues(zeroGrid);
  }
  if (vramSheet) {
    vramSheet.getRange("B2:AG33").setBackground(SSX_COLOR_PALETTE[0]);
  }
  ss.toast("RAM and VRAM Cleared to 0.", "SSX Silicon 1", 3);
}

function loadProgramIntoRom(programWords, programName) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const romSheet = ss.getSheetByName("ROM_STORAGE");
  if (!romSheet) return;

  const grid = [];
  let wordIdx = 0;
  for (let r = 0; r < 256; r++) {
    const row = [];
    for (let c = 0; c < 16; c++) {
      if (wordIdx < programWords.length) {
        row.push("0x" + (programWords[wordIdx] >>> 0).toString(16).toUpperCase().padStart(8, "0"));
      } else {
        row.push("0x00000000");
      }
      wordIdx++;
    }
    grid.push(row);
  }
  romSheet.getRange(2, 2, 256, 16).setValues(grid);
  ssxResetCpu();
  ss.toast(`Loaded ${programName} (${programWords.length} words). Ready to run!`, "SSX Silicon 1", 4);
}

function ssxLoadSelfTest() { loadProgramIntoRom(DEMO_PROGRAMS.SELF_TEST, "Hardware Self-Test"); }
function ssxLoadFibonacci() { loadProgramIntoRom(DEMO_PROGRAMS.FIBONACCI, "32-Bit Fibonacci"); }
function ssxLoadPrimeSieve() { loadProgramIntoRom(DEMO_PROGRAMS.PRIME_SIEVE, "Prime Sieve"); }
function ssxLoadMatrixMultiply() { loadProgramIntoRom(DEMO_PROGRAMS.MATRIX_MULTIPLY, "3x3 Matrix Multiplication"); }
function ssxLoadGraphicsDemo() { loadProgramIntoRom(DEMO_PROGRAMS.GRAPHICS_DEMO, "32x32 Graphics Demo"); }

function ssxBenchmark() {
  const t0 = new Date().getTime();
  ssxStepNCycles(500);
  const t1 = new Date().getTime();
  const elapsedSec = (t1 - t0) / 1000.0;
  const ips = elapsedSec > 0 ? Math.round(500 / elapsedSec) : 500;
  SpreadsheetApp.getActiveSpreadsheet().toast(`Benchmark: 500 instructions in ${elapsedSec.toFixed(2)}s (${ips} IPS)`, "SSX Silicon 1 Benchmark", 5);
}

function ssxShowAbout() {
  const ui = SpreadsheetApp.getUi();
  ui.alert(
    "SSX Silicon 1 (SSX-32) Architecture\n" +
    "Creator: Samin Sami (SS)\n\n" +
    "Specifications:\n" +
    "- True 32-Bit Architecture\n" +
    "- 32 General-Purpose 32-Bit Registers (R0-R31)\n" +
    "- 32-Bit Arithmetic Logic Unit (ALU)\n" +
    "- Status Flags: Zero (ZF), Carry (CF), Sign (SF), Overflow (OF)\n" +
    "- 4096 32-Bit Words RAM & ROM Storage\n" +
    "- 32x32 Color Graphics VRAM with 16-Color Palette\n" +
    "- Dual Execution: Native Formula Recalculation + High-Speed Apps Script Engine"
  );
}

// Module export for Node.js test harness
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    DEMO_PROGRAMS,
    updateArithmeticFlags,
    updateLogicFlags,
    SSX_COLOR_PALETTE
  };
}
