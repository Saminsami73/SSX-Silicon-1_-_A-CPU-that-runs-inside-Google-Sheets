"""
SSX Silicon 1 (SSX-32) Master Google Sheets CPU Builder
Creator: Samin Sami (SS)
Generates the complete SSX_Silicon_1_CPU.xlsx workbook with all formulas,
registers, ALU, RAM, ROM, 32x32 VRAM display, and reference documentation.
"""

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import CellIsRule
import os

def create_cpu_workbook(output_path: str, rom_words: list = None):
    wb = openpyxl.Workbook()
    default_sheet = wb.active
    wb.remove(default_sheet)

    # Styles & Palettes
    FONT_TITLE = Font(name="Segoe UI", size=14, bold=True, color="FFFFFF")
    FONT_HEADER = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
    FONT_SUBHEADER = Font(name="Segoe UI", size=9, bold=True, color="94A3B8")
    FONT_CODE = Font(name="Consolas", size=10, bold=False, color="E2E8F0")
    FONT_CODE_BOLD = Font(name="Consolas", size=10, bold=True, color="38BDF8")
    FONT_ACCENT = Font(name="Consolas", size=10, bold=True, color="F59E0B")
    FONT_GREEN = Font(name="Consolas", size=10, bold=True, color="10B981")
    FONT_BLACK = Font(name="Consolas", size=9, color="000000")

    FILL_BG_DARK = PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")
    FILL_HEADER_BAR = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
    FILL_CARD = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
    FILL_CYAN = PatternFill(start_color="0891B2", end_color="0891B2", fill_type="solid")
    FILL_AMBER = PatternFill(start_color="D97706", end_color="D97706", fill_type="solid")
    FILL_EMERALD = PatternFill(start_color="059669", end_color="059669", fill_type="solid")
    FILL_INPUT = PatternFill(start_color="334155", end_color="334155", fill_type="solid")

    THIN_BORDER = Border(
        left=Side(style='thin', color='334155'),
        right=Side(style='thin', color='334155'),
        top=Side(style='thin', color='334155'),
        bottom=Side(style='thin', color='334155')
    )

    ALIGN_CENTER = Alignment(horizontal="center", vertical="center")
    ALIGN_LEFT = Alignment(horizontal="left", vertical="center")
    ALIGN_RIGHT = Alignment(horizontal="right", vertical="center")

    # =========================================================================
    # SHEET 1: CONTROL_DASHBOARD
    # =========================================================================
    ws_dash = wb.create_sheet(title="CONTROL_DASHBOARD")
    ws_dash.views.sheetView[0].showGridLines = True

    # Title Banner
    ws_dash.merge_cells("A1:N1")
    title_cell = ws_dash["A1"]
    title_cell.value = "SSX SILICON 1 // 32-BIT PROCESSOR SYSTEM // ARCHITECTURE: SSX-32 [DEVELOPER: SAMIN SAMI (SS)]"
    title_cell.font = FONT_TITLE
    title_cell.fill = FILL_CYAN
    title_cell.alignment = ALIGN_CENTER
    ws_dash.row_dimensions[1].height = 32

    # System Controls (Row 3-4)
    ctrl_headers = [
        ("B3", "MASTER CLOCK", "B4", "=IF(B4=0, 1, 0)", FILL_AMBER),
        ("D3", "CPU RESET", "D4", 0, FILL_INPUT),
        ("F3", "STEP MODE", "F4", "AUTO", FILL_INPUT),
        ("H3", "LOAD ROM", "H4", 0, FILL_INPUT),
        ("J3", "RESET RAM", "J4", 0, FILL_INPUT),
        ("L3", "MANUAL EXEC", "L4", 0, FILL_INPUT)
    ]
    for lbl_c, lbl, val_c, val, fill in ctrl_headers:
        c_lbl = ws_dash[lbl_c]
        c_lbl.value = lbl
        c_lbl.font = FONT_HEADER
        c_lbl.fill = FILL_HEADER_BAR
        c_lbl.alignment = ALIGN_CENTER
        c_lbl.border = THIN_BORDER

        c_val = ws_dash[val_c]
        c_val.value = val
        c_val.font = FONT_CODE_BOLD
        c_val.fill = fill
        c_val.alignment = ALIGN_CENTER
        c_val.border = THIN_BORDER

    ws_dash.row_dimensions[3].height = 20
    ws_dash.row_dimensions[4].height = 24

    # Core Registers & Status (Row 6-12)
    ws_dash["B6"].value = "PROGRAM COUNTER (PC)"
    ws_dash["B6"].font = FONT_HEADER
    ws_dash["B6"].fill = FILL_HEADER_BAR
    ws_dash["D6"].value = "=ALU_32!F25"
    ws_dash["D6"].font = FONT_CODE_BOLD
    ws_dash["D6"].fill = FILL_CARD
    ws_dash["D6"].alignment = ALIGN_CENTER

    ws_dash["B8"].value = "CYCLE COUNTER"
    ws_dash["B8"].font = FONT_HEADER
    ws_dash["B8"].fill = FILL_HEADER_BAR
    ws_dash["D8"].value = "=IF(D4, 0, IF(B4, D8 + 1, D8))"
    ws_dash["D8"].font = FONT_ACCENT
    ws_dash["D8"].fill = FILL_CARD
    ws_dash["D8"].alignment = ALIGN_CENTER

    ws_dash["B10"].value = "STATUS FLAGS (HEX)"
    ws_dash["B10"].font = FONT_HEADER
    ws_dash["B10"].fill = FILL_HEADER_BAR
    ws_dash["D10"].value = "=ALU_32!G16"
    ws_dash["D10"].font = FONT_GREEN
    ws_dash["D10"].fill = FILL_CARD
    ws_dash["D10"].alignment = ALIGN_CENTER

    ws_dash["F10"].value = "=CONCATENATE(\"[ZF:\", ALU_32!B16, \" CF:\", ALU_32!C16, \" SF:\", ALU_32!D16, \" OF:\", ALU_32!E16, \"]\")"
    ws_dash["F10"].font = FONT_CODE_BOLD
    ws_dash["F10"].fill = FILL_CARD
    ws_dash["F10"].alignment = ALIGN_CENTER

    ws_dash["B12"].value = "EXECUTION STATE"
    ws_dash["B12"].font = FONT_HEADER
    ws_dash["B12"].fill = FILL_HEADER_BAR
    ws_dash["D12"].value = "=IF(D4, \"RESET\", IF(D16=1, \"HALTED\", \"RUNNING\"))"
    ws_dash["D12"].font = FONT_CODE_BOLD
    ws_dash["D12"].fill = FILL_CARD
    ws_dash["D12"].alignment = ALIGN_CENTER

    # Instruction Register & Decode Unit (Row 14-16)
    ws_dash["B14"].value = "INSTRUCTION REGISTER (IR)"
    ws_dash["B14"].font = FONT_TITLE
    ws_dash["B14"].fill = FILL_CYAN
    ws_dash.merge_cells("B14:N14")

    ir_headers = ["IR RAW (HEX)", "OPCODE", "MNEMONIC", "RD", "RS1", "RS2", "IMM9 SIGNED", "TWO-WORD"]
    ir_cols = ["B", "D", "F", "H", "J", "L", "M", "N"]
    for i, h in enumerate(ir_headers):
        c = ws_dash[f"{ir_cols[i]}15"]
        c.value = h
        c.font = FONT_HEADER
        c.fill = FILL_HEADER_BAR
        c.alignment = ALIGN_CENTER
        c.border = THIN_BORDER

    # Robust PC evaluation: handles both raw numbers (0, 1) and hex strings ("0x0000")
    dash_pc_expr = "IF(ISNUMBER(D6), D6, HEX2DEC(MID(D6, 3, 8)))"

    # Fetch word at PC:
    ws_dash["B16"].value = f'=INDIRECT(ADDRESS(INT(({dash_pc_expr})/16) + 2, MOD(({dash_pc_expr}), 16) + 2, 4, 1, "ROM_STORAGE"))'
    ws_dash["B16"].font = FONT_CODE_BOLD
    ws_dash["B16"].fill = FILL_CARD
    ws_dash["B16"].alignment = ALIGN_CENTER

    # Opcode
    ws_dash["D16"].value = '=HEX2DEC(MID(B16, 3, 2))'
    ws_dash["D16"].font = FONT_ACCENT
    ws_dash["D16"].fill = FILL_CARD
    ws_dash["D16"].alignment = ALIGN_CENTER

    # Mnemonic
    ws_dash["F16"].value = '=IFERROR(VLOOKUP(D16, INSTRUCTION_SET!A3:B40, 2, FALSE), "UNKNOWN")'
    ws_dash["F16"].font = FONT_CODE_BOLD
    ws_dash["F16"].fill = FILL_CARD
    ws_dash["F16"].alignment = ALIGN_CENTER

    # RD
    ws_dash["H16"].value = '=INT(MOD(HEX2DEC(MID(B16, 3, 8)) / 524288, 32))'
    ws_dash["H16"].font = FONT_CODE
    ws_dash["H16"].fill = FILL_CARD
    ws_dash["H16"].alignment = ALIGN_CENTER

    # RS1
    ws_dash["J16"].value = '=INT(MOD(HEX2DEC(MID(B16, 3, 8)) / 16384, 32))'
    ws_dash["J16"].font = FONT_CODE
    ws_dash["J16"].fill = FILL_CARD
    ws_dash["J16"].alignment = ALIGN_CENTER

    # RS2
    ws_dash["L16"].value = '=INT(MOD(HEX2DEC(MID(B16, 3, 8)) / 512, 32))'
    ws_dash["L16"].font = FONT_CODE
    ws_dash["L16"].fill = FILL_CARD
    ws_dash["L16"].alignment = ALIGN_CENTER

    # IMM9 Signed
    ws_dash["M16"].value = '=IF(MOD(HEX2DEC(MID(B16, 3, 8)), 512) >= 256, MOD(HEX2DEC(MID(B16, 3, 8)), 512) - 512, MOD(HEX2DEC(MID(B16, 3, 8)), 512))'
    ws_dash["M16"].font = FONT_CODE
    ws_dash["M16"].fill = FILL_CARD
    ws_dash["M16"].alignment = ALIGN_CENTER

    # Two-Word Instruction Indicator
    ws_dash["N16"].value = '=IF(OR(D16=19, D16=20, AND(D16>=80, D16<=89)), 1, 0)'
    ws_dash["N16"].font = FONT_ACCENT
    ws_dash["N16"].fill = FILL_CARD
    ws_dash["N16"].alignment = ALIGN_CENTER

    # Live Disassembly & Instruction Bus
    ws_dash["B18"].value = "INSTRUCTION BUS & LIVE DISASSEMBLY"
    ws_dash["B18"].font = FONT_HEADER
    ws_dash["B18"].fill = FILL_HEADER_BAR
    ws_dash.merge_cells("B18:N18")

    ws_dash["B19"].value = '=CONCATENATE(F16, "  R", H16, ",  R", J16, ",  R", L16, "  [#", M16, "]")'
    ws_dash["B19"].font = FONT_CODE_BOLD
    ws_dash["B19"].fill = FILL_BG_DARK
    ws_dash["B19"].alignment = ALIGN_CENTER
    ws_dash.merge_cells("B19:N19")
    ws_dash.row_dimensions[19].height = 24

    # Hardware MMIO Output Port 0x2003 Monitor
    ws_dash["B22"].value = "HARDWARE MMIO PORT 0x2003 (STATUS MONITOR)"
    ws_dash["B22"].font = FONT_HEADER
    ws_dash["B22"].fill = FILL_HEADER_BAR
    ws_dash.merge_cells("B22:G22")

    ws_dash["B23"].value = "=REGISTERS_32!C5" # Displays R1 output
    ws_dash["B23"].font = FONT_TITLE
    ws_dash["B23"].fill = FILL_CARD
    ws_dash["B23"].alignment = ALIGN_CENTER
    ws_dash.merge_cells("B23:G23")
    ws_dash.row_dimensions[23].height = 30

    for col in ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N"]:
        ws_dash.column_dimensions[col].width = 16

    # =========================================================================
    # SHEET 2: REGISTERS_32
    # =========================================================================
    ws_reg = wb.create_sheet(title="REGISTERS_32")
    ws_reg.views.sheetView[0].showGridLines = True

    ws_reg.merge_cells("A1:G1")
    r_title = ws_reg["A1"]
    r_title.value = "SSX-32 REGISTER FILE // 32 GENERAL-PURPOSE 32-BIT REGISTERS [R0 TO R31]"
    r_title.font = FONT_TITLE
    r_title.fill = FILL_EMERALD
    r_title.alignment = ALIGN_CENTER
    ws_reg.row_dimensions[1].height = 28

    reg_cols = [
        ("A", "INDEX", 8),
        ("B", "REGISTER", 12),
        ("C", "HEX VALUE (32-BIT)", 24),
        ("D", "SIGNED INT", 16),
        ("E", "UNSIGNED INT", 16),
        ("F", "ALIAS / ROLE", 18),
        ("G", "WRITE ENABLE", 14)
    ]
    for col, h_name, w in reg_cols:
        c = ws_reg[f"{col}3"]
        c.value = h_name
        c.font = FONT_HEADER
        c.fill = FILL_HEADER_BAR
        c.alignment = ALIGN_CENTER
        c.border = THIN_BORDER
        ws_reg.column_dimensions[col].width = w

    ws_reg.row_dimensions[3].height = 22

    aliases = {
        0: "ZERO (Hardwired 0)",
        1: "T0 (Scratch / Ret 0)",
        2: "T1 (Scratch / Ret 1)",
        3: "T2 (Scratch / Ret 2)",
        4: "A0 (Argument 0)",
        5: "A1 (Argument 1)",
        6: "A2 (Argument 2)",
        7: "A3 (Argument 3)",
        27: "RH (High 32-bit Mul/Div)",
        28: "FP (Frame Pointer)",
        29: "SP (Stack Pointer)",
        30: "LR (Link Register)",
        31: "PC (Program Counter)"
    }

    for i in range(32):
        row = 4 + i
        ws_reg.row_dimensions[row].height = 18

        ws_reg[f"A{row}"].value = i
        ws_reg[f"A{row}"].font = FONT_CODE
        ws_reg[f"A{row}"].alignment = ALIGN_CENTER
        ws_reg[f"A{row}"].fill = FILL_HEADER_BAR

        ws_reg[f"B{row}"].value = f"R{i}"
        ws_reg[f"B{row}"].font = FONT_CODE_BOLD
        ws_reg[f"B{row}"].alignment = ALIGN_CENTER
        ws_reg[f"B{row}"].fill = FILL_CARD

        default_val = "0x00003FFF" if i == 29 else "0x00000000"
        reg_formula = f'=IF(CONTROL_DASHBOARD!$D$4, "{default_val}", IF(AND(CONTROL_DASHBOARD!$B$4, CONTROL_DASHBOARD!$H$16={i}, ALU_32!$H$28), ALU_32!$F$10, C{row}))'
        if i == 0:
            reg_formula = '"0x00000000"'

        c_hex = ws_reg[f"C{row}"]
        c_hex.value = reg_formula
        c_hex.font = FONT_CODE_BOLD
        c_hex.alignment = ALIGN_CENTER
        c_hex.fill = FILL_INPUT

        ws_reg[f"D{row}"].value = f'=IF(HEX2DEC(MID(C{row}, 3, 8)) >= 2147483648, HEX2DEC(MID(C{row}, 3, 8)) - 4294967296, HEX2DEC(MID(C{row}, 3, 8)))'
        ws_reg[f"D{row}"].font = FONT_CODE
        ws_reg[f"D{row}"].alignment = ALIGN_RIGHT

        ws_reg[f"E{row}"].value = f'=HEX2DEC(MID(C{row}, 3, 8))'
        ws_reg[f"E{row}"].font = FONT_CODE
        ws_reg[f"E{row}"].alignment = ALIGN_RIGHT

        ws_reg[f"F{row}"].value = aliases.get(i, f"S{i-8}" if 8 <= i <= 26 else "")
        ws_reg[f"F{row}"].font = FONT_SUBHEADER
        ws_reg[f"F{row}"].alignment = ALIGN_LEFT

        ws_reg[f"G{row}"].value = f'=IF(AND(CONTROL_DASHBOARD!$H$16={i}, ALU_32!$H$28), 1, 0)'
        ws_reg[f"G{row}"].font = FONT_GREEN
        ws_reg[f"G{row}"].alignment = ALIGN_CENTER

    # =========================================================================
    # SHEET 3: ALU_32
    # =========================================================================
    ws_alu = wb.create_sheet(title="ALU_32")
    ws_alu.views.sheetView[0].showGridLines = True

    ws_alu.merge_cells("A1:H1")
    alu_title = ws_alu["A1"]
    alu_title.value = "SSX-32 ARITHMETIC LOGIC UNIT & EXECUTION ENGINE"
    alu_title.font = FONT_TITLE
    alu_title.fill = FILL_AMBER
    alu_title.alignment = ALIGN_CENTER
    ws_alu.row_dimensions[1].height = 28

    ws_alu["B3"].value = "OPERAND 1 (RS1)"
    ws_alu["B3"].font = FONT_HEADER
    ws_alu["B3"].fill = FILL_HEADER_BAR
    ws_alu["C3"].value = "=INDIRECT(ADDRESS(CONTROL_DASHBOARD!J16 + 4, 3, 4, 1, \"REGISTERS_32\"))"
    ws_alu["C3"].font = FONT_CODE_BOLD
    ws_alu["C3"].fill = FILL_CARD
    ws_alu["C3"].alignment = ALIGN_CENTER

    ws_alu["E3"].value = "OPERAND 2 (RS2 / IMM)"
    ws_alu["E3"].font = FONT_HEADER
    ws_alu["E3"].fill = FILL_HEADER_BAR
    ws_alu["F3"].value = "=IF(OR(CONTROL_DASHBOARD!D16=33, CONTROL_DASHBOARD!D16=35, CONTROL_DASHBOARD!D16=49, CONTROL_DASHBOARD!D16=51, CONTROL_DASHBOARD!D16=53, CONTROL_DASHBOARD!D16=65), DEC2HEX(CONTROL_DASHBOARD!M16, 8), INDIRECT(ADDRESS(CONTROL_DASHBOARD!L16 + 4, 3, 4, 1, \"REGISTERS_32\")))"
    ws_alu["F3"].font = FONT_CODE_BOLD
    ws_alu["F3"].fill = FILL_CARD
    ws_alu["F3"].alignment = ALIGN_CENTER

    ws_alu["B5"].value = "OP1 VALUE (DEC)"
    ws_alu["C5"].value = "=HEX2DEC(MID(C3, 3, 8))"
    ws_alu["C5"].font = FONT_CODE

    ws_alu["E5"].value = "OP2 VALUE (DEC)"
    ws_alu["F5"].value = "=HEX2DEC(MID(F3, 3, 8))"
    ws_alu["F5"].font = FONT_CODE

    ws_alu["B8"].value = "ALU OPERATION"
    ws_alu["B8"].font = FONT_HEADER
    ws_alu["B8"].fill = FILL_HEADER_BAR
    ws_alu["C8"].value = "=CONTROL_DASHBOARD!F16"
    ws_alu["C8"].font = FONT_CODE_BOLD
    ws_alu["C8"].fill = FILL_CARD
    ws_alu["C8"].alignment = ALIGN_CENTER

    global_pc_expr = "IF(ISNUMBER(CONTROL_DASHBOARD!$D$6), CONTROL_DASHBOARD!$D$6, HEX2DEC(MID(CONTROL_DASHBOARD!$D$6, 3, 8)))"
    next_word_target = f'HEX2DEC(MID(INDIRECT(ADDRESS(INT((({global_pc_expr})+1)/16)+2, MOD((({global_pc_expr})+1), 16)+2, 4, 1, "ROM_STORAGE")), 3, 8))'

    ws_alu["E8"].value = "RAW ALU RESULT (DEC)"
    ws_alu["E8"].font = FONT_HEADER
    ws_alu["E8"].fill = FILL_HEADER_BAR
    ws_alu["F8"].value = (
        '=IF(OR(C8="ADD", C8="ADDI"), C5 + F5, '
        'IF(OR(C8="SUB", C8="SUBI", C8="CMP", C8="CMPI"), C5 - F5, '
        'IF(C8="MUL", MOD(C5 * F5, 4294967296), '
        'IF(C8="DIV", IF(F5=0, 4294967295, INT(C5 / F5)), '
        'IF(C8="MOD", IF(F5=0, 0, MOD(C5, F5)), '
        'IF(C8="AND", BITAND(C5, F5), '
        'IF(C8="OR", BITOR(C5, F5), '
        'IF(C8="XOR", BITXOR(C5, F5), '
        'IF(C8="SHL", MOD(BITLSHIFT(C5, MOD(F5, 32)), 4294967296), '
        'IF(C8="SHR", BITRSHIFT(C5, MOD(F5, 32)), '
        'IF(C8="MOV", C5, '
        f'IF(C8="LOADI", {next_word_target}, C5))))))))))))'
    )
    ws_alu["F8"].font = FONT_ACCENT

    ws_alu["B10"].value = "RESULT (32-BIT HEX)"
    ws_alu["B10"].font = FONT_HEADER
    ws_alu["B10"].fill = FILL_HEADER_BAR
    ws_alu["F10"].value = '="0x" & DEC2HEX(MOD(F8, 4294967296), 8)'
    ws_alu["F10"].font = FONT_CODE_BOLD
    ws_alu["F10"].fill = FILL_CARD
    ws_alu["F10"].alignment = ALIGN_CENTER

    flag_defs = [
        ("B15", "ZF (ZERO)", "B16", '=IF(MOD(F8, 4294967296)=0, 1, 0)'),
        ("C15", "CF (CARRY)", "C16", '=IF(OR(C8="ADD", C8="ADDI"), IF((C5+F5)>=4294967296, 1, 0), IF(OR(C8="SUB", C8="SUBI", C8="CMP", C8="CMPI"), IF(C5<F5, 1, 0), 0))'),
        ("D15", "SF (SIGN)", "D16", '=IF(MOD(F8, 4294967296)>=2147483648, 1, 0)'),
        ("E15", "OF (OVERFLOW)", "E16", '=IF(OR(C8="ADD", C8="ADDI"), IF(AND(C5<2147483648, F5<2147483648, (C5+F5)>=2147483648), 1, 0), 0)'),
        ("G15", "PACKED FLAGS (HEX)", "G16", '=DEC2HEX(B16 + C16*2 + D16*4 + E16*8, 2)')
    ]
    for lbl_c, lbl, val_c, val in flag_defs:
        ws_alu[lbl_c].value = lbl
        ws_alu[lbl_c].font = FONT_HEADER
        ws_alu[lbl_c].fill = FILL_HEADER_BAR
        ws_alu[lbl_c].alignment = ALIGN_CENTER
        ws_alu[val_c].value = val
        ws_alu[val_c].font = FONT_CODE_BOLD
        ws_alu[val_c].fill = FILL_CARD
        ws_alu[val_c].alignment = ALIGN_CENTER

    ws_alu["B20"].value = "BRANCH CONDITION EVALUATION"
    ws_alu["B20"].font = FONT_HEADER
    ws_alu["B20"].fill = FILL_HEADER_BAR
    ws_alu.merge_cells("B20:H20")

    ws_alu["B22"].value = "BRANCH TAKEN?"
    ws_alu["B22"].font = FONT_HEADER
    ws_alu["C22"].value = (
        '=IF(CONTROL_DASHBOARD!F16="JMP", 1, '
        'IF(OR(CONTROL_DASHBOARD!F16="JE", CONTROL_DASHBOARD!F16="JZ"), B16=1, '
        'IF(OR(CONTROL_DASHBOARD!F16="JNE", CONTROL_DASHBOARD!F16="JNZ"), B16=0, '
        'IF(CONTROL_DASHBOARD!F16="JL", D16<>E16, '
        'IF(CONTROL_DASHBOARD!F16="JG", AND(B16=0, D16=E16), '
        'IF(CONTROL_DASHBOARD!F16="JGE", D16=E16, '
        'IF(CONTROL_DASHBOARD!F16="JC", C16=1, '
        'IF(CONTROL_DASHBOARD!F16="JNC", C16=0, 0))))))))'
    )
    ws_alu["C22"].font = FONT_CODE_BOLD
    ws_alu["C22"].fill = FILL_CARD
    ws_alu["C22"].alignment = ALIGN_CENTER

    # Robust next PC calculation
    ws_alu["B25"].value = "NEXT PC"
    ws_alu["B25"].font = FONT_HEADER
    ws_alu["F25"].value = (
        f'=IF(CONTROL_DASHBOARD!$D$4, 0, '
        f'IF(CONTROL_DASHBOARD!$B$4, '
        f'IF(C22=1, {next_word_target}, ({global_pc_expr}) + 1 + CONTROL_DASHBOARD!$N$16), ({global_pc_expr})))'
    )
    ws_alu["F25"].font = FONT_ACCENT
    ws_alu["F25"].fill = FILL_CARD
    ws_alu["F25"].alignment = ALIGN_CENTER

    ws_alu["B28"].value = "REG WRITE ENABLE"
    ws_alu["H28"].value = '=IF(OR(CONTROL_DASHBOARD!F16="ADD", CONTROL_DASHBOARD!F16="ADDI", CONTROL_DASHBOARD!F16="SUB", CONTROL_DASHBOARD!F16="SUBI", CONTROL_DASHBOARD!F16="MUL", CONTROL_DASHBOARD!F16="DIV", CONTROL_DASHBOARD!F16="AND", CONTROL_DASHBOARD!F16="OR", CONTROL_DASHBOARD!F16="XOR", CONTROL_DASHBOARD!F16="MOV", CONTROL_DASHBOARD!F16="LOADI", CONTROL_DASHBOARD!F16="LOAD"), 1, 0)'
    ws_alu["H28"].font = FONT_GREEN
    ws_alu["H28"].alignment = ALIGN_CENTER

    for col in ["A", "B", "C", "D", "E", "F", "G", "H"]:
        ws_alu.column_dimensions[col].width = 18

    # =========================================================================
    # SHEET 4: RAM_MEMORY (4096 Words, 256 rows x 16 cols)
    # =========================================================================
    ws_ram = wb.create_sheet(title="RAM_MEMORY")
    ws_ram.views.sheetView[0].showGridLines = True

    ws_ram["A1"].value = "ADDR"
    ws_ram["A1"].font = FONT_HEADER
    ws_ram["A1"].fill = FILL_HEADER_BAR
    ws_ram["A1"].alignment = ALIGN_CENTER
    ws_ram.column_dimensions["A"].width = 10

    for c in range(16):
        col_letter = get_column_letter(c + 2)
        ws_ram[f"{col_letter}1"].value = f"+{c:X}"
        ws_ram[f"{col_letter}1"].font = FONT_HEADER
        ws_ram[f"{col_letter}1"].fill = FILL_HEADER_BAR
        ws_ram[f"{col_letter}1"].alignment = ALIGN_CENTER
        ws_ram.column_dimensions[col_letter].width = 14

    for r in range(256):
        row_num = r + 2
        base_addr = r * 16
        ws_ram[f"A{row_num}"].value = f"0x{base_addr:04X}"
        ws_ram[f"A{row_num}"].font = FONT_SUBHEADER
        ws_ram[f"A{row_num}"].alignment = ALIGN_CENTER

        for c in range(16):
            col_letter = get_column_letter(c + 2)
            cell_coord = f"{col_letter}{row_num}"
            ram_formula = f'=IF(CONTROL_DASHBOARD!$J$4, "0x00000000", IF(CONTROL_DASHBOARD!$H$4, ROM_STORAGE!{cell_coord}, {cell_coord}))'
            ws_ram[cell_coord].value = ram_formula
            ws_ram[cell_coord].font = FONT_CODE
            ws_ram[cell_coord].alignment = ALIGN_CENTER

    # =========================================================================
    # SHEET 5: ROM_STORAGE (4096 Words, Preloaded)
    # =========================================================================
    ws_rom = wb.create_sheet(title="ROM_STORAGE")
    ws_rom.views.sheetView[0].showGridLines = True

    ws_rom["A1"].value = "ADDR"
    ws_rom["A1"].font = FONT_HEADER
    ws_rom["A1"].fill = FILL_HEADER_BAR
    ws_rom["A1"].alignment = ALIGN_CENTER
    ws_rom.column_dimensions["A"].width = 10

    for c in range(16):
        col_letter = get_column_letter(c + 2)
        ws_rom[f"{col_letter}1"].value = f"+{c:X}"
        ws_rom[f"{col_letter}1"].font = FONT_HEADER
        ws_rom[f"{col_letter}1"].fill = FILL_HEADER_BAR
        ws_rom[f"{col_letter}1"].alignment = ALIGN_CENTER
        ws_rom.column_dimensions[col_letter].width = 14

    words_to_write = rom_words if rom_words else [0]
    word_ptr = 0

    for r in range(256):
        row_num = r + 2
        base_addr = r * 16
        ws_rom[f"A{row_num}"].value = f"0x{base_addr:04X}"
        ws_rom[f"A{row_num}"].font = FONT_SUBHEADER
        ws_rom[f"A{row_num}"].alignment = ALIGN_CENTER

        for c in range(16):
            col_letter = get_column_letter(c + 2)
            val = words_to_write[word_ptr] if word_ptr < len(words_to_write) else 0
            hex_str = f"0x{val:08X}"
            ws_rom[f"{col_letter}{row_num}"].value = hex_str
            ws_rom[f"{col_letter}{row_num}"].font = FONT_CODE
            ws_rom[f"{col_letter}{row_num}"].alignment = ALIGN_CENTER
            word_ptr += 1

    # =========================================================================
    # SHEET 6: DISPLAY_SCREEN (32x32 Color Matrix)
    # =========================================================================
    ws_vram = wb.create_sheet(title="DISPLAY_SCREEN")
    ws_vram.views.sheetView[0].showGridLines = True

    ws_vram.column_dimensions["A"].width = 6
    ws_vram.row_dimensions[1].height = 20

    for x in range(32):
        col_letter = get_column_letter(x + 2)
        ws_vram.column_dimensions[col_letter].width = 3.6
        c = ws_vram[f"{col_letter}1"]
        c.value = str(x)
        c.font = FONT_BLACK
        c.alignment = ALIGN_CENTER

    for y in range(32):
        row_num = y + 2
        ws_vram.row_dimensions[row_num].height = 18
        c_lbl = ws_vram[f"A{row_num}"]
        c_lbl.value = str(y)
        c_lbl.font = FONT_BLACK
        c_lbl.alignment = ALIGN_CENTER

        for x in range(32):
            col_letter = get_column_letter(x + 2)
            cell = ws_vram[f"{col_letter}{row_num}"]
            cell.value = 0
            cell.font = FONT_BLACK
            cell.alignment = ALIGN_CENTER
            cell.fill = PatternFill(start_color="0B0E14", end_color="0B0E14", fill_type="solid")

    colors_hex = [
        "0B0E14", "1D4ED8", "059669", "06B6D4", "DC2626", "9333EA", "D97706", "E2E8F0",
        "475569", "3B82F6", "10B981", "22D3EE", "EF4444", "F472B6", "FBBF24", "FFFFFF"
    ]
    for idx, hex_col in enumerate(colors_hex):
        fill_rule = PatternFill(start_color=hex_col, end_color=hex_col, fill_type="solid")
        rule = CellIsRule(operator='equal', formula=[str(idx)], stopIfTrue=True, fill=fill_rule)
        ws_vram.conditional_formatting.add("B2:AG33", rule)

    # =========================================================================
    # SHEET 7: INSTRUCTION_SET
    # =========================================================================
    ws_isa = wb.create_sheet(title="INSTRUCTION_SET")
    ws_isa.views.sheetView[0].showGridLines = True

    ws_isa.merge_cells("A1:F1")
    isa_title = ws_isa["A1"]
    isa_title.value = "SSX-32 INSTRUCTION SET ARCHITECTURE // 36 ORTHOGONAL 32-BIT OPCODES"
    isa_title.font = FONT_TITLE
    isa_title.fill = FILL_CYAN
    isa_title.alignment = ALIGN_CENTER
    ws_isa.row_dimensions[1].height = 28

    isa_headers = [
        ("A", "OPCODE (HEX)", 14),
        ("B", "MNEMONIC", 14),
        ("C", "SYNTAX / OPERANDS", 26),
        ("D", "DESCRIPTION & SEMANTICS", 45),
        ("E", "FLAGS AFFECTED", 18),
        ("F", "WORDS", 10)
    ]
    for col, h, w in isa_headers:
        c = ws_isa[f"{col}2"]
        c.value = h
        c.font = FONT_HEADER
        c.fill = FILL_HEADER_BAR
        c.alignment = ALIGN_CENTER
        c.border = THIN_BORDER
        ws_isa.column_dimensions[col].width = w

    instructions_data = [
        (0x00, "NOP", "NOP", "No operation performed", "None", 1),
        (0x01, "HLT", "HLT", "Halts processor execution", "None", 1),
        (0x02, "RESET", "RESET", "Clears registers and restarts from address 0", "None", 1),
        (0x03, "SYS", "SYS #code", "Executes system call with code in imm9", "None", 1),
        (0x04, "CLC", "CLC", "Clears Carry Flag (CF = 0)", "CF", 1),
        (0x05, "STC", "STC", "Sets Carry Flag (CF = 1)", "CF", 1),
        (0x10, "MOV", "MOV Rd, Rs", "Copies 32-bit value from Rs to Rd", "None", 1),
        (0x11, "LOAD", "LOAD Rd, [Rs]", "Loads 32-bit word from Memory[Rs] into Rd", "None", 1),
        (0x12, "STORE", "STORE Rs, [Rd]", "Stores 32-bit word Rs into Memory[Rd]", "None", 1),
        (0x13, "LOADI", "LOADI Rd, #imm32", "Loads 32-bit immediate constant into Rd", "None", 2),
        (0x14, "STOREI", "STOREI #imm32, [Rd]", "Stores 32-bit immediate directly into Memory[Rd]", "None", 2),
        (0x15, "PUSH", "PUSH Rs", "Decrements SP and pushes Rs to memory stack", "None", 1),
        (0x16, "POP", "POP Rd", "Pops 32-bit word from stack into Rd and increments SP", "None", 1),
        (0x20, "ADD", "ADD Rd, Rs1, Rs2", "Rd = Rs1 + Rs2 (32-bit arithmetic addition)", "ZF, CF, SF, OF", 1),
        (0x21, "ADDI", "ADDI Rd, Rs1, #imm9", "Rd = Rs1 + imm9 (9-bit signed immediate addition)", "ZF, CF, SF, OF", 1),
        (0x22, "SUB", "SUB Rd, Rs1, Rs2", "Rd = Rs1 - Rs2 (32-bit arithmetic subtraction)", "ZF, CF, SF, OF", 1),
        (0x23, "SUBI", "SUBI Rd, Rs1, #imm9", "Rd = Rs1 - imm9 (9-bit signed immediate subtraction)", "ZF, CF, SF, OF", 1),
        (0x24, "MUL", "MUL Rd, Rs1, Rs2", "Rd = (Rs1 * Rs2)[31:0]; R27 = (Rs1 * Rs2)[63:32]", "ZF, SF", 1),
        (0x25, "DIV", "DIV Rd, Rs1, Rs2", "Rd = Rs1 / Rs2; R27 = Rs1 % Rs2 (Unsigned 32-bit)", "ZF, SF", 1),
        (0x26, "MOD", "MOD Rd, Rs1, Rs2", "Rd = Rs1 % Rs2 (Modulo remainder)", "ZF, SF", 1),
        (0x27, "INC", "INC Rd", "Rd = Rd + 1", "ZF, SF", 1),
        (0x28, "DEC", "DEC Rd", "Rd = Rd - 1", "ZF, SF", 1),
        (0x29, "NEG", "NEG Rd", "Rd = -Rd (Two's complement negation)", "ZF, SF", 1),
        (0x30, "AND", "AND Rd, Rs1, Rs2", "Rd = Rs1 & Rs2 (Bitwise AND)", "ZF, SF", 1),
        (0x31, "ANDI", "ANDI Rd, Rs1, #imm9", "Rd = Rs1 & imm9", "ZF, SF", 1),
        (0x32, "OR", "OR Rd, Rs1, Rs2", "Rd = Rs1 | Rs2 (Bitwise OR)", "ZF, SF", 1),
        (0x33, "ORI", "ORI Rd, Rs1, #imm9", "Rd = Rs1 | imm9", "ZF, SF", 1),
        (0x34, "XOR", "XOR Rd, Rs1, Rs2", "Rd = Rs1 ^ Rs2 (Bitwise Exclusive-OR)", "ZF, SF", 1),
        (0x35, "XORI", "XORI Rd, Rs1, #imm9", "Rd = Rs1 ^ imm9", "ZF, SF", 1),
        (0x36, "NOT", "NOT Rd", "Rd = ~Rd (Bitwise bit inversion)", "ZF, SF", 1),
        (0x37, "SHL", "SHL Rd, Rs, #shift", "Logical left shift by shift count (0 to 31)", "ZF, SF", 1),
        (0x38, "SHR", "SHR Rd, Rs, #shift", "Logical right shift (zero-fill)", "ZF, SF", 1),
        (0x39, "SAR", "SAR Rd, Rs, #shift", "Arithmetic right shift (sign-preserving)", "ZF, SF", 1),
        (0x3A, "ROL", "ROL Rd, Rs, #shift", "Rotate left by shift count", "ZF, SF", 1),
        (0x3B, "ROR", "ROR Rd, Rs, #shift", "Rotate right by shift count", "ZF, SF", 1),
        (0x40, "CMP", "CMP Rs1, Rs2", "Compares Rs1 with Rs2 via subtraction", "ZF, CF, SF, OF", 1),
        (0x41, "CMPI", "CMPI Rs1, #imm9", "Compares Rs1 with 9-bit immediate", "ZF, CF, SF, OF", 1),
        (0x50, "JMP", "JMP #target", "Unconditional jump to 32-bit address", "None", 2),
        (0x51, "JE", "JE #target", "Jump if Equal / Zero (ZF = 1)", "None", 2),
        (0x52, "JNE", "JNE #target", "Jump if Not Equal (ZF = 0)", "None", 2),
        (0x53, "JL", "JL #target", "Jump if Less than signed (SF != OF)", "None", 2),
        (0x55, "JG", "JG #target", "Jump if Greater than signed (ZF=0 and SF==OF)", "None", 2),
        (0x56, "JGE", "JGE #target", "Jump if Greater or Equal signed (SF == OF)", "None", 2),
        (0x57, "JC", "JC #target", "Jump if Carry Set / Unsigned lower (CF = 1)", "None", 2),
        (0x58, "JNC", "JNC #target", "Jump if Carry Clear (CF = 0)", "None", 2),
        (0x59, "CALL", "CALL #target", "Calls subroutine: pushes return address to stack", "None", 2),
        (0x5A, "RET", "RET", "Returns from subroutine: pops return address to PC", "None", 1),
        (0x60, "OUT", "OUT #port, Rs", "Outputs 32-bit value to hardware I/O port", "None", 1),
        (0x61, "IN", "IN Rd, #port", "Reads 32-bit value from hardware I/O port", "None", 1),
        (0x62, "VSET", "VSET Rx, Ry, Rc", "Sets VRAM pixel at (Rx, Ry) to 4-bit color Rc", "None", 1),
        (0x63, "VCLR", "VCLR #color", "Clears entire 32x32 screen to color", "None", 1)
    ]

    for idx, (op, mnem, syntax, desc, flags, words) in enumerate(instructions_data):
        row = 3 + idx
        ws_isa.row_dimensions[row].height = 20
        ws_isa[f"A{row}"].value = f"0x{op:02X}"
        ws_isa[f"A{row}"].font = FONT_ACCENT
        ws_isa[f"A{row}"].alignment = ALIGN_CENTER

        ws_isa[f"B{row}"].value = mnem
        ws_isa[f"B{row}"].font = FONT_CODE_BOLD
        ws_isa[f"B{row}"].alignment = ALIGN_CENTER

        ws_isa[f"C{row}"].value = syntax
        ws_isa[f"C{row}"].font = FONT_CODE
        ws_isa[f"C{row}"].alignment = ALIGN_LEFT

        ws_isa[f"D{row}"].value = desc
        ws_isa[f"D{row}"].font = FONT_CODE
        ws_isa[f"D{row}"].alignment = ALIGN_LEFT

        ws_isa[f"E{row}"].value = flags
        ws_isa[f"E{row}"].font = FONT_GREEN
        ws_isa[f"E{row}"].alignment = ALIGN_CENTER

        ws_isa[f"F{row}"].value = words
        ws_isa[f"F{row}"].font = FONT_CODE
        ws_isa[f"F{row}"].alignment = ALIGN_CENTER

    # =========================================================================
    # SHEET 8: USER_MANUAL
    # =========================================================================
    ws_man = wb.create_sheet(title="USER_MANUAL")
    ws_man.views.sheetView[0].showGridLines = True

    ws_man.merge_cells("A1:G1")
    man_title = ws_man["A1"]
    man_title.value = "SSX SILICON 1 // OPERATING MANUAL & INTEGRATION GUIDE"
    man_title.font = FONT_TITLE
    man_title.fill = FILL_CYAN
    man_title.alignment = ALIGN_CENTER
    ws_man.row_dimensions[1].height = 28

    manual_text = [
        ("A3", "1. How to Import and Setup in Google Sheets", FONT_HEADER, FILL_HEADER_BAR),
        ("A4", "Step 1: Open Google Sheets in any browser (https://sheets.google.com).", FONT_CODE, None),
        ("A5", "Step 2: Go to File > Import > Upload, and select SSX_Silicon_1_CPU.xlsx.", FONT_CODE, None),
        ("A6", "Step 3: Select 'Replace spreadsheet' and click Import data.", FONT_CODE, None),
        ("A7", "Step 4: Go to File > Settings > Calculation.", FONT_CODE, None),
        ("A8", "Step 5: Turn ON 'Iterative calculation', set Maximum number of iterations to 1, and click Save settings.", FONT_CODE, None),
        ("A10", "2. Two Operating Modes", FONT_HEADER, FILL_HEADER_BAR),
        ("A11", "Mode A (Pure Formula Engine): Toggle cell B4 on CONTROL_DASHBOARD to pulse the master clock. Each edit advances the CPU.", FONT_CODE, None),
        ("A12", "Mode B (High-Speed Apps Script Engine): Go to Extensions > Apps Script, paste scripts/SSX_Silicon_Engine.js, and click Save.", FONT_CODE, None),
        ("A13", "This adds the 'SSX Silicon 1' menu to your top bar with 1-click Run, Step, Reset, and Demo Loaders running at hundreds of IPS.", FONT_CODE, None),
        ("A15", "3. Architecture Summary", FONT_HEADER, FILL_HEADER_BAR),
        ("A16", "• True 32-bit registers (R0 through R31) with hardwired zero (R0), stack pointer (R29), and link register (R30).", FONT_CODE, None),
        ("A17", "• 32-bit ALU with arithmetic, bitwise logic, barrel shifts, rotates, and flag updates (ZF, CF, SF, OF).", FONT_CODE, None),
        ("A18", "• 4096 words RAM (16 KB) and 4096 words ROM storage.", FONT_CODE, None),
        ("A19", "• 32x32 color graphics display mapped to VRAM at 0x2400 with 16-color palette.", FONT_CODE, None),
        ("A21", "4. Developer & Attribution", FONT_HEADER, FILL_HEADER_BAR),
        ("A22", "Architected and created by Samin Sami (SS). Designed for high-performance spreadsheet computing competitions.", FONT_CODE, None)
    ]

    for coord, text, font, fill in manual_text:
        c = ws_man[coord]
        c.value = text
        c.font = font
        if fill:
            c.fill = fill
        ws_man.merge_cells(f"{coord}:G{coord[1:]}")

    ws_man.column_dimensions["A"].width = 90

    wb.save(output_path)
    print(f"Master CPU workbook saved: {output_path}")

if __name__ == '__main__':
    words = []
    bin_path = os.path.join(os.path.dirname(__file__), "..", "programs", "01_hardware_selftest.bin")
    if os.path.isfile(bin_path):
        with open(bin_path, "rb") as f:
            data = f.read()
        words = [int.from_bytes(data[i:i+4], "big") for i in range(0, len(data), 4)]

    out_xlsx = os.path.join(os.path.dirname(__file__), "..", "SSX_Silicon_1_CPU.xlsx")
    create_cpu_workbook(out_xlsx, words)
