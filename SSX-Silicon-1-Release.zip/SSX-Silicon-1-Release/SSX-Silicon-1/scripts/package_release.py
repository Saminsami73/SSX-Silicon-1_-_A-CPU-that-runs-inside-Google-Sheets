"""
SSX Silicon 1 (SSX-32) Release Packager
Creator: Samin Sami (SS)
Packages the complete production project into a GitHub-ready zip archive.
"""

import os
import zipfile
import hashlib

def create_release_zip():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    repo_name = "SSX-Silicon-1"
    output_zip = os.path.join(base_dir, "..", "SSX-Silicon-1-Release.zip")
    output_zip = os.path.abspath(output_zip)

    # Excluded extensions and patterns
    exclude_dirs = {".git", "__pycache__", ".vscode", ".idea"}
    exclude_exts = {".pyc", ".pyo"}

    print(f"Creating release package: {output_zip}")
    file_count = 0
    total_bytes = 0

    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(base_dir):
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            for file in files:
                if any(file.endswith(ext) for ext in exclude_exts):
                    continue
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, base_dir)
                archive_name = os.path.join(repo_name, rel_path).replace("\\", "/")
                zf.write(full_path, archive_name)
                file_count += 1
                total_bytes += os.path.getsize(full_path)

    # Also compute SHA-256 of the zip
    sha256 = hashlib.sha256()
    with open(output_zip, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            sha256.update(chunk)

    zip_size_kb = os.path.getsize(output_zip) / 1024.0
    print(f"Package created successfully:")
    print(f"  Files packaged: {file_count}")
    print(f"  Uncompressed payload: {total_bytes / 1024.0:.1f} KB")
    print(f"  Archive size: {zip_size_kb:.1f} KB")
    print(f"  SHA-256: {sha256.hexdigest()}")

if __name__ == "__main__":
    create_release_zip()

