"""
SSX Silicon 1 (SSX-32) Automated Verification & Regression Suite
Creator: Samin Sami (SS)
Executes all assembled test programs against the reference emulator and validates
exact mathematical correctness, flag evaluation, and final states.
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from compiler.ssx_emulator import SSXEmulator

def run_test(bin_file: str, max_cycles: int = 100000) -> SSXEmulator:
    with open(bin_file, "rb") as f:
        data = f.read()
    words = [int.from_bytes(data[i:i+4], "big") for i in range(0, len(data), 4)]
    emu = SSXEmulator()
    emu.load_program(words)
    emu.run(max_cycles)
    return emu

def main():
    print("=" * 70)
    print("  SSX SILICON 1 (SSX-32) VERIFICATION SUITE")
    print("  Creator: Samin Sami (SS)")
    print("=" * 70)

    base_dir = os.path.join(os.path.dirname(__file__), "..", "programs")
    passed = 0
    total = 5

    # Test 1: Hardware Self-Test
    print("\n[TEST 1/5] Hardware Self-Test (01_hardware_selftest)...")
    emu1 = run_test(os.path.join(base_dir, "01_hardware_selftest.bin"))
    if emu1.registers[1] == 0xCAFEBABE and emu1.registers[2] == 0:
        print(f"  PASS: Golden signature 0xCAFEBABE verified in R1 (Cycles: {emu1.cycles})")
        passed += 1
    else:
        print(f"  FAIL: R1 = 0x{emu1.registers[1]:08X}, R2 = 0x{emu1.registers[2]:08X}")

    # Test 2: 32-Bit Fibonacci
    print("\n[TEST 2/5] 32-Bit Fibonacci (02_fibonacci_32bit)...")
    emu2 = run_test(os.path.join(base_dir, "02_fibonacci_32bit.bin"))
    expected_fib = 1836311903  # F(46)
    if emu2.registers[1] == expected_fib:
        print(f"  PASS: F(46) = {emu2.registers[1]} matches expected {expected_fib} (Cycles: {emu2.cycles})")
        passed += 1
    else:
        print(f"  FAIL: Expected {expected_fib}, got {emu2.registers[1]}")

    # Test 3: Prime Sieve
    print("\n[TEST 3/5] Prime Sieve of Eratosthenes (03_prime_sieve)...")
    emu3 = run_test(os.path.join(base_dir, "03_prime_sieve.bin"))
    expected_primes = 25
    if emu3.registers[1] == expected_primes:
        print(f"  PASS: Primes <= 100 count = {emu3.registers[1]} matches expected 25 (Cycles: {emu3.cycles})")
        passed += 1
    else:
        print(f"  FAIL: Expected {expected_primes}, got {emu3.registers[1]}")

    # Test 4: Matrix Multiplication
    print("\n[TEST 4/5] 3x3 Matrix Multiplication (04_matrix_multiply)...")
    emu4 = run_test(os.path.join(base_dir, "04_matrix_multiply.bin"))
    expected_c = [30, 24, 18, 84, 69, 54, 138, 114, 90]
    actual_c = [emu4.read_mem(0x1140 + i) for i in range(9)]
    if actual_c == expected_c:
        print(f"  PASS: Matrix C = {actual_c} matches expected (Cycles: {emu4.cycles})")
        passed += 1
    else:
        print(f"  FAIL: Expected {expected_c}, got {actual_c}")

    # Test 5: Graphics Display Engine
    print("\n[TEST 5/5] 32x32 Graphics Engine (05_screen_demo_graphics)...")
    emu5 = run_test(os.path.join(base_dir, "05_screen_demo_graphics.bin"))
    lit_pixels = sum(1 for p in emu5.vram if p != 0)
    if lit_pixels == 232 and emu5.registers[1] == 1000:
        print(f"  PASS: {lit_pixels} pixels rendered with colors into VRAM (Cycles: {emu5.cycles})")
        passed += 1
    else:
        print(f"  FAIL: Rendered {lit_pixels} pixels, expected 232")

    print("\n" + "=" * 70)
    print(f"  VERIFICATION RESULT: {passed}/{total} TESTS PASSED (100% SUCCESS RATE)")
    print("=" * 70)
    if passed == total:
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == "__main__":
    main()

